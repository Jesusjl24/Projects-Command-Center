import { cn } from "@/lib/utils";

interface Props {
  value: number; // 0-100
  className?: string;
  tone?: "primary" | "success" | "warning" | "danger";
  showLabel?: boolean;
}

const toneClass = {
  primary: "gradient-primary",
  success: "bg-success",
  warning: "bg-warning",
  danger: "bg-destructive",
} as const;

export function ProgressBar({ value, className, tone = "primary", showLabel = false }: Props) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div className={cn("w-full", className)}>
      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
        <div className={cn("h-full rounded-full transition-all", toneClass[tone])} style={{ width: `${v}%` }} />
      </div>
      {showLabel && <div className="mt-1 text-[11px] text-muted-foreground">{v}%</div>}
    </div>
  );
}
