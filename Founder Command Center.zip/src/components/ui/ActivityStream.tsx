import type { ActivityEvent } from "@/lib/types";
import { Bot, Shield, Wrench, Cog } from "lucide-react";
import { cn } from "@/lib/utils";

const iconFor = (t?: ActivityEvent["type"]) => {
  switch (t) {
    case "security": return Shield;
    case "build": return Wrench;
    case "product": return Bot;
    default: return Cog;
  }
};
const toneFor = (t?: ActivityEvent["type"]) => {
  switch (t) {
    case "security": return "text-destructive bg-destructive/10";
    case "build": return "text-info bg-info/10";
    case "product": return "text-primary bg-primary/10";
    default: return "text-muted-foreground bg-muted";
  }
};

export function ActivityStream({ events, className }: { events: ActivityEvent[]; className?: string }) {
  if (events.length === 0) {
    return <div className={cn("text-sm text-muted-foreground", className)}>No agent activity yet.</div>;
  }
  return (
    <ul className={cn("space-y-3", className)}>
      {events.map((e) => {
        const Icon = iconFor(e.type);
        return (
          <li key={e.id} className="flex items-start gap-3">
            <div className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg", toneFor(e.type))}>
              <Icon className="h-4 w-4" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-baseline gap-x-2">
                <span className="text-sm font-medium text-foreground">{e.agent}</span>
                <span className="text-[11px] text-muted-foreground">{new Date(e.timestamp).toLocaleString()}</span>
              </div>
              <p className="text-sm text-muted-foreground">{e.message}</p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
