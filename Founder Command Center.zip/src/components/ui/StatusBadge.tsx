import { cn } from "@/lib/utils";
import type { Priority, Severity, Stage, BuildStatus, AgentStatus, FindingStatus, TaskStatus } from "@/lib/types";

type Variant =
  | { kind: "stage"; value: Stage }
  | { kind: "build"; value: BuildStatus }
  | { kind: "priority"; value: Priority }
  | { kind: "severity"; value: Severity }
  | { kind: "agent"; value: AgentStatus }
  | { kind: "finding"; value: FindingStatus }
  | { kind: "task"; value: TaskStatus };

const cls = (color: string) => `border-transparent bg-${color}/15 text-${color}`;

function styleFor(v: Variant): string {
  const base = "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium whitespace-nowrap";
  switch (v.kind) {
    case "stage":
      switch (v.value) {
        case "Building": return `${base} bg-info/15 text-info border-info/20`;
        case "Testing": return `${base} bg-warning/15 text-warning border-warning/20`;
        case "Launched": return `${base} bg-success/15 text-success border-success/20`;
        case "Paused": return `${base} bg-muted text-muted-foreground border-border`;
        default: return `${base} bg-muted text-muted-foreground border-border`;
      }
    case "build":
      switch (v.value) {
        case "Building": return `${base} bg-info/15 text-info border-info/20`;
        case "Paused": return `${base} bg-warning/15 text-warning border-warning/20`;
        case "Blocked": return `${base} bg-destructive/15 text-destructive border-destructive/20`;
        case "Ready": return `${base} bg-success/15 text-success border-success/20`;
        case "Launched": return `${base} bg-success/15 text-success border-success/20`;
        default: return `${base} bg-muted text-muted-foreground border-border`;
      }
    case "priority":
      switch (v.value) {
        case "Critical": return `${base} bg-destructive/15 text-destructive border-destructive/20`;
        case "High": return `${base} bg-primary/20 text-primary border-primary/30`;
        case "Medium": return `${base} bg-info/15 text-info border-info/20`;
        default: return `${base} bg-muted text-muted-foreground border-border`;
      }
    case "severity":
      switch (v.value) {
        case "Critical": return `${base} bg-destructive/20 text-destructive border-destructive/30`;
        case "High": return `${base} bg-destructive/15 text-destructive border-destructive/20`;
        case "Medium": return `${base} bg-warning/15 text-warning border-warning/20`;
        default: return `${base} bg-info/15 text-info border-info/20`;
      }
    case "agent":
      switch (v.value) {
        case "Running": return `${base} bg-success/15 text-success border-success/20`;
        case "Idle": return `${base} bg-muted text-muted-foreground border-border`;
        case "Paused": return `${base} bg-warning/15 text-warning border-warning/20`;
        case "Blocked": return `${base} bg-destructive/15 text-destructive border-destructive/20`;
      }
    case "finding":
      switch (v.value) {
        case "Open": return `${base} bg-destructive/15 text-destructive border-destructive/20`;
        case "Fixed": return `${base} bg-success/15 text-success border-success/20`;
        case "Accepted": return `${base} bg-muted text-muted-foreground border-border`;
        case "False Positive": return `${base} bg-info/15 text-info border-info/20`;
      }
    case "task":
      switch (v.value) {
        case "Done": return `${base} bg-success/15 text-success border-success/20`;
        case "In Progress": return `${base} bg-info/15 text-info border-info/20`;
        case "Blocked": return `${base} bg-destructive/15 text-destructive border-destructive/20`;
        case "Review": return `${base} bg-warning/15 text-warning border-warning/20`;
        default: return `${base} bg-muted text-muted-foreground border-border`;
      }
  }
}

export function StatusBadge(props: Variant & { className?: string }) {
  return <span className={cn(styleFor(props), props.className)}>{props.value}</span>;
}

// Silence unused import lint for cls helper kept for future use
void cls;
