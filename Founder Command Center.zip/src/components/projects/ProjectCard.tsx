import { Link } from "@tanstack/react-router";
import type { Project } from "@/lib/types";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { money, daysRemaining } from "@/lib/analytics";
import { Bot, ShieldAlert, ListTodo, ArrowRight } from "lucide-react";

export function ProjectCard({ project }: { project: Project }) {
  const openFindings = project.findings.filter((f) => f.status === "Open").length;
  const openTasks = project.tasks.filter((t) => t.status !== "Done").length;
  const dr = daysRemaining(project.deadline);

  return (
    <Link
      to="/projects/$id"
      params={{ id: project.id }}
      className="group panel flex flex-col gap-4 p-5 transition-all hover:border-primary/40 hover:shadow-[0_0_40px_-10px_var(--primary)]"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-base font-semibold text-foreground group-hover:text-gradient">{project.name}</h3>
          <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{project.description}</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5">
        <StatusBadge kind="stage" value={project.stage} />
        <StatusBadge kind="build" value={project.buildStatus} />
        <StatusBadge kind="priority" value={project.priority} />
      </div>

      <div>
        <div className="mb-1 flex items-center justify-between text-[11px] text-muted-foreground">
          <span>Progress</span>
          <span className="font-medium text-foreground">{project.progress}%</span>
        </div>
        <ProgressBar value={project.progress} />
      </div>

      <div className="grid grid-cols-2 gap-3 text-xs">
        <div>
          <div className="text-muted-foreground">Est. build</div>
          <div className="font-medium text-foreground">{money(project.budget)}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Monthly stack</div>
          <div className="font-medium text-foreground">{money(project.stackMonthlyCost)}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Days remaining</div>
          <div className={`font-medium ${dr < 7 ? "text-warning" : "text-foreground"}`}>{dr}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Deadline</div>
          <div className="font-medium text-foreground">{project.deadline}</div>
        </div>
      </div>

      <div className="flex items-center justify-between border-t border-border/60 pt-3 text-xs text-muted-foreground">
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1"><Bot className="h-3.5 w-3.5" />{project.agents.length}</span>
          <span className="inline-flex items-center gap-1"><ShieldAlert className={`h-3.5 w-3.5 ${openFindings ? "text-destructive" : ""}`} />{openFindings}</span>
          <span className="inline-flex items-center gap-1"><ListTodo className="h-3.5 w-3.5" />{openTasks}</span>
        </div>
        <span className="inline-flex items-center gap-1 font-medium text-primary group-hover:translate-x-0.5 transition-transform">
          Open <ArrowRight className="h-3.5 w-3.5" />
        </span>
      </div>
    </Link>
  );
}
