import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import {
  LayoutDashboard,
  FolderKanban,
  Bot,
  ShieldCheck,
  BarChart3,
  Settings,
  MessageSquare,
  Rocket,
} from "lucide-react";
import { useStore } from "@/lib/store";

const NAV = [
  { title: "Overview", url: "/overview", icon: LayoutDashboard },
  { title: "Projects", url: "/projects", icon: FolderKanban },
  { title: "Copilot", url: "/copilot", icon: MessageSquare },
  { title: "Agents", url: "/agents", icon: Bot },
  { title: "Security", url: "/security", icon: ShieldCheck },
  { title: "Analytics", url: "/analytics", icon: BarChart3 },
  { title: "Settings", url: "/settings", icon: Settings },
] as const;

export function CommandPalette({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const navigate = useNavigate();
  const projects = useStore((s) => s.projects);

  const go = (fn: () => void) => {
    onOpenChange(false);
    // let dialog close animation begin before navigating
    setTimeout(fn, 0);
  };

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput placeholder="Jump to a page or project…" />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Navigate">
          {NAV.map((n) => (
            <CommandItem
              key={n.url}
              value={`nav ${n.title}`}
              onSelect={() => go(() => navigate({ to: n.url }))}
            >
              <n.icon className="mr-2 h-4 w-4 text-muted-foreground" />
              <span>{n.title}</span>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Projects">
          {projects.map((p) => (
            <CommandItem
              key={p.id}
              value={`project ${p.name} ${p.description}`}
              onSelect={() => go(() => navigate({ to: "/projects/$id", params: { id: p.id } }))}
            >
              <Rocket className="mr-2 h-4 w-4 text-primary" />
              <div className="flex min-w-0 flex-col">
                <span className="truncate text-sm text-foreground">{p.name}</span>
                <span className="truncate text-[11px] text-muted-foreground">
                  {p.stage} · {p.buildStatus}
                </span>
              </div>
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}

export function useCommandPalette() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  return { open, setOpen };
}
