import { createServerFn } from "@tanstack/react-start";
import { generateText, NoObjectGeneratedError, Output } from "ai";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import type {
  ActivityEvent,
  AgentType,
  Priority,
  Project,
  SecurityFinding,
  Severity,
  Task,
  TaskStatus,
} from "@/lib/types";

const AGENT_TYPES = ["Manager", "Builder", "Security", "Research"] as const;

const RunInput = z.object({
  projectId: z.string().min(1),
  agentType: z.enum(AGENT_TYPES),
});

const TaskStatusSchema = z.enum(["Backlog", "In Progress", "Blocked", "Review", "Done"]);
const PrioritySchema = z.enum(["Low", "Medium", "High", "Critical"]);
const SeveritySchema = z.enum(["Low", "Medium", "High", "Critical"]);

const AgentOutputSchema = z.object({
  summary: z.string(),
  activityMessage: z.string(),
  taskUpdates: z.array(
    z.object({
      taskId: z.string(),
      status: TaskStatusSchema.nullable(),
      priority: PrioritySchema.nullable(),
    }),
  ),
  newTasks: z.array(
    z.object({
      title: z.string(),
      priority: PrioritySchema,
      owner: z.string().nullable(),
    }),
  ),
  newFindings: z.array(
    z.object({
      title: z.string(),
      severity: SeveritySchema,
      category: z.string(),
      recommendation: z.string(),
      blocksLaunch: z.boolean(),
    }),
  ),
});

type AgentOutput = z.infer<typeof AgentOutputSchema>;

const SYSTEM_BY_AGENT: Record<AgentType, string> = {
  Manager:
    "You are a Manager agent (product/PM). Advance the project by updating task statuses, proposing at most 2 new tasks, and posting a status note. Ground everything strictly in the provided project state. Do not invent findings.",
  Builder:
    "You are a Builder agent (frontend/engineering). Advance in-progress tasks, unblock what you can, and propose at most 2 concrete build tasks with acceptance criteria in the title. Do not create security findings.",
  Security:
    "You are Sentinel, a Security agent. Review only what the project state shows. Add at most 2 new findings grounded in real gaps in the state (auth, secrets, PII, agent permissions, deploy). Do not add tasks unless directly remediating a finding.",
  Research:
    "You are a Research agent. Post a short research note and, if useful, propose at most 1 research task. Do not modify task statuses or add findings.",
};

function summarizeProject(p: Project): string {
  const openFindings = p.findings.filter((f) => f.status === "Open");
  const blockedTasks = p.tasks.filter((t) => t.status === "Blocked");
  return [
    `Project: ${p.name}`,
    `Stage: ${p.stage} · Build: ${p.buildStatus} · Progress: ${p.progress}%`,
    `Deadline: ${p.deadline} · Budget: $${p.budget} · Monthly stack: $${p.stackMonthlyCost}`,
    `MVP goal: ${p.mvpGoal}`,
    `Target user: ${p.targetUser}`,
    "",
    `Tasks (${p.tasks.length}):`,
    ...p.tasks.map(
      (t) => `- [id:${t.id}] (${t.status}, ${t.priority}${t.owner ? `, ${t.owner}` : ""}) ${t.title}`,
    ),
    "",
    `Open findings (${openFindings.length}):`,
    ...openFindings.map((f) => `- (${f.severity}) ${f.title} — ${f.recommendation}`),
    "",
    `Blocked tasks: ${blockedTasks.length}`,
    `Recent activity:`,
    ...p.activity.slice(-5).map((a) => `- ${a.agent}: ${a.message}`),
  ].join("\n");
}

function applyAgentOutput(
  project: Project,
  agentType: AgentType,
  agentName: string,
  output: AgentOutput,
): { updated: Project; applied: { taskUpdates: number; newTasks: number; newFindings: number } } {
  const now = new Date().toISOString();
  const runSuffix = now.replace(/[^0-9]/g, "").slice(-8);

  // Task updates
  let taskUpdatesApplied = 0;
  const patchedTasks: Task[] = project.tasks.map((t) => {
    const upd = output.taskUpdates.find((u) => u.taskId === t.id);
    if (!upd) return t;
    taskUpdatesApplied += 1;
    return {
      ...t,
      status: (upd.status ?? t.status) as TaskStatus,
      priority: (upd.priority ?? t.priority) as Priority,
    };
  });

  // New tasks (cap to 3 defensively)
  const newTasks: Task[] = output.newTasks.slice(0, 3).map((nt, i) => ({
    id: `${project.id}-t-${runSuffix}-${i}`,
    title: nt.title.slice(0, 200),
    status: "Backlog" as TaskStatus,
    priority: nt.priority as Priority,
    owner: nt.owner ?? agentName,
  }));

  // New findings (cap to 3)
  const newFindings: SecurityFinding[] = output.newFindings.slice(0, 3).map((nf, i) => ({
    id: `${project.id}-f-${runSuffix}-${i}`,
    title: nf.title.slice(0, 200),
    severity: nf.severity as Severity,
    category: nf.category.slice(0, 60),
    status: "Open",
    recommendation: nf.recommendation,
    owner: agentName,
    blocksLaunch: nf.blocksLaunch,
  }));

  const activityEvent: ActivityEvent = {
    id: `${project.id}-a-${runSuffix}`,
    agent: agentName,
    message: output.activityMessage.slice(0, 400),
    timestamp: now,
    type:
      agentType === "Security"
        ? "security"
        : agentType === "Builder"
          ? "build"
          : agentType === "Manager"
            ? "product"
            : "system",
  };

  const updated: Project = {
    ...project,
    tasks: [...patchedTasks, ...newTasks],
    findings: [...project.findings, ...newFindings],
    activity: [...project.activity, activityEvent].slice(-40),
  };

  return {
    updated,
    applied: {
      taskUpdates: taskUpdatesApplied,
      newTasks: newTasks.length,
      newFindings: newFindings.length,
    },
  };
}

export const runAgentTurn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => RunInput.parse(d))
  .handler(async ({ data, context }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");

    // Load project (RLS scopes to owner)
    const { data: row, error } = await context.supabase
      .from("projects")
      .select("id, data")
      .eq("id", data.projectId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) throw new Error("Project not found");

    const project = row.data as unknown as Project;
    const agent =
      project.agents.find((a) => a.type === data.agentType) ??
      project.agents[0] ?? {
        name: `${data.agentType} agent`,
        type: data.agentType,
      };

    const gateway = createLovableAiGatewayProvider(key);
    const model = "google/gemini-3-flash-preview";
    const system = SYSTEM_BY_AGENT[data.agentType];
    const prompt = `Take one turn as this agent. Use ONLY existing task ids from the context for taskUpdates. Keep summary <= 2 sentences.\n\n${summarizeProject(project)}`;

    let ai: AgentOutput;
    try {
      const { output } = await generateText({
        model: gateway(model),
        system,
        prompt,
        output: Output.object({ schema: AgentOutputSchema }),
      });
      ai = output;
    } catch (err) {
      if (NoObjectGeneratedError.isInstance(err)) {
        throw new Error("Agent produced malformed output — please try again.");
      }
      throw err;
    }

    const { updated, applied } = applyAgentOutput(project, data.agentType, agent.name, ai);

    // Persist project
    const { error: upErr } = await context.supabase.from("projects").upsert({
      id: updated.id,
      owner_id: context.userId,
      data: updated as never,
    });
    if (upErr) throw new Error(upErr.message);

    // Log run
    const { data: runRow, error: runErr } = await context.supabase
      .from("agent_runs")
      .insert({
        project_id: updated.id,
        owner_id: context.userId,
        agent_type: data.agentType,
        agent_name: agent.name,
        summary: ai.summary,
        changes: { applied, activityMessage: ai.activityMessage },
        model,
        status: "success",
      })
      .select("id, created_at")
      .single();
    if (runErr) throw new Error(runErr.message);

    return {
      run: {
        id: runRow.id,
        createdAt: runRow.created_at,
        agentType: data.agentType,
        agentName: agent.name,
        summary: ai.summary,
        applied,
      },
      project: updated,
    };
  });

export interface AgentRun {
  id: string;
  createdAt: string;
  agentType: AgentType;
  agentName: string;
  summary: string;
  status: string;
  model: string | null;
  applied: { taskUpdates: number; newTasks: number; newFindings: number };
  activityMessage?: string;
}

export const listAgentRuns = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ projectId: z.string().min(1) }).parse(d))
  .handler(async ({ data, context }): Promise<AgentRun[]> => {
    const { data: rows, error } = await context.supabase
      .from("agent_runs")
      .select("id, created_at, agent_type, agent_name, summary, status, model, changes")
      .eq("project_id", data.projectId)
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return (rows ?? []).map((r) => {
      const changes = (r.changes ?? {}) as {
        applied?: { taskUpdates?: number; newTasks?: number; newFindings?: number };
        activityMessage?: string;
      };
      return {
        id: r.id,
        createdAt: r.created_at,
        agentType: r.agent_type as AgentType,
        agentName: r.agent_name,
        summary: r.summary,
        status: r.status,
        model: r.model,
        applied: {
          taskUpdates: changes.applied?.taskUpdates ?? 0,
          newTasks: changes.applied?.newTasks ?? 0,
          newFindings: changes.applied?.newFindings ?? 0,
        },
        activityMessage: changes.activityMessage,
      };
    });
  });
