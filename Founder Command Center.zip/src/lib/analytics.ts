import type { Project } from "./types";

export const money = (v: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(v);

export const daysBetween = (a: string | Date, b: string | Date) => {
  const d1 = new Date(a).getTime();
  const d2 = new Date(b).getTime();
  return Math.round((d2 - d1) / (1000 * 60 * 60 * 24));
};

export const daysRemaining = (deadline: string) => daysBetween(new Date(), deadline);

export function healthScore(project: Project): number {
  const progress = project.progress;
  const velocity = project.buildVelocity;
  const openHighFindings = project.findings.filter(
    (f) => f.status === "Open" && (f.severity === "High" || f.severity === "Critical"),
  ).length;
  const blockedTasks = project.tasks.filter((t) => t.status === "Blocked").length;
  const score =
    progress * 0.4 +
    velocity * 0.2 +
    Math.max(0, 100 - openHighFindings * 25) * 0.25 +
    Math.max(0, 100 - blockedTasks * 20) * 0.15;
  return Math.round(Math.max(0, Math.min(100, score)));
}

export function launchReadiness(project: Project): number {
  const progress = project.progress;
  const highOpen = project.findings.filter(
    (f) => f.status === "Open" && (f.severity === "High" || f.severity === "Critical"),
  ).length;
  const securityScore = Math.max(0, 100 - highOpen * 40);
  const decisionsScore = Math.min(100, project.decisions.length * 25);
  const openTasks = project.tasks.filter((t) => t.status !== "Done").length;
  const tasksScore = Math.max(0, 100 - openTasks * 10);
  const score = progress * 0.4 + securityScore * 0.3 + decisionsScore * 0.15 + tasksScore * 0.15;
  return Math.round(Math.max(0, Math.min(100, score)));
}

export function analytics(project: Project) {
  const agentSpent = project.agents.reduce((s, a) => s + a.hourlyRate * a.hoursUsed, 0);
  const elapsed = project.startedAt ? Math.max(0, daysBetween(project.startedAt, new Date())) : 0;
  const stackSpent = Math.round((elapsed / 30) * project.stackMonthlyCost);
  const spent = agentSpent + stackSpent;
  const remaining = Math.max(0, project.budget - spent);
  const budgetPressure = Math.min(100, Math.round((spent / Math.max(1, project.budget)) * 100));
  const remainingDays = daysRemaining(project.deadline);
  return {
    agentSpent,
    stackSpent,
    spent,
    remaining,
    budgetPressure,
    elapsedDays: elapsed,
    remainingDays,
    estimatedTotal: project.budget,
  };
}

export function portfolioAnalytics(projects: Project[]) {
  const totalBudget = projects.reduce((s, p) => s + p.budget, 0);
  const monthlyStack = projects.reduce((s, p) => s + p.stackMonthlyCost, 0);
  const agentHours = projects.reduce((s, p) => s + p.agents.reduce((x, a) => x + a.hoursUsed, 0), 0);
  const openFindings = projects.reduce(
    (s, p) => s + p.findings.filter((f) => f.status === "Open").length,
    0,
  );
  const activeBuilds = projects.filter((p) => p.buildStatus === "Building").length;
  const avgReadiness =
    projects.length === 0
      ? 0
      : Math.round(projects.reduce((s, p) => s + launchReadiness(p), 0) / projects.length);
  const avgHealth =
    projects.length === 0 ? 0 : Math.round(projects.reduce((s, p) => s + healthScore(p), 0) / projects.length);
  const totalSpent = projects.reduce((s, p) => s + analytics(p).spent, 0);
  return { totalBudget, monthlyStack, agentHours, openFindings, activeBuilds, avgReadiness, avgHealth, totalSpent };
}

export function generateHandoff(project: Project): string {
  const a = analytics(project);
  const openTasks = project.tasks.filter((t) => t.status !== "Done");
  const nextAction =
    project.findings.find((f) => f.status === "Open" && (f.severity === "High" || f.severity === "Critical"))
      ?.recommendation ||
    openTasks[0]?.title ||
    "Confirm MVP acceptance criteria with product lead.";

  return `# ${project.name} — Handoff Package

## Status
- Stage: ${project.stage}
- Build status: ${project.buildStatus}
- Priority: ${project.priority}
- Progress: ${project.progress}%
- Deadline: ${project.deadline}
- Elapsed days: ${a.elapsedDays}
- Remaining days: ${a.remainingDays}
- Estimated total build cost: ${money(project.budget)}
- Monthly stack cost: ${money(project.stackMonthlyCost)}
${project.pauseReason ? `- Pause reason: ${project.pauseReason}` : ""}

## PDR Summary
${project.description}

### Problem
${project.problem}

### Target user
${project.targetUser}

### MVP goal
${project.mvpGoal}

## Tech Stack
- Frontend: ${project.techStack.frontend}
- Styling: ${project.techStack.styling}
- Backend: ${project.techStack.backend}
- Database: ${project.techStack.database}
- Auth: ${project.techStack.auth}
- Hosting: ${project.techStack.hosting}
- Design: ${project.techStack.design}
- Rationale: ${project.techStack.rationale}

## Agent Roster
${project.agents
  .map(
    (ag) =>
      `- **${ag.name}** — ${ag.role} (${ag.type}, ${ag.provider}/${ag.model}) — YOLO: ${ag.yoloMode} — Status: ${ag.status} — Hours: ${ag.hoursUsed} @ ${money(ag.hourlyRate)}/hr`,
  )
  .join("\n")}

## Open Tasks
${openTasks.length === 0 ? "_None_" : openTasks.map((t) => `- [${t.status}] (${t.priority}) ${t.title}${t.owner ? ` — ${t.owner}` : ""}`).join("\n")}

## Security Findings
${
  project.findings.length === 0
    ? "_None_"
    : project.findings
        .map(
          (f) =>
            `- **[${f.severity}] ${f.title}** (${f.category}) — ${f.status}${f.blocksLaunch ? " — BLOCKS LAUNCH" : ""}\n  Recommendation: ${f.recommendation}`,
        )
        .join("\n")
}

## Decisions
${project.decisions.length === 0 ? "_None_" : project.decisions.map((d) => `- ${d.decision} _(${d.createdAt})_`).join("\n")}

## Next Recommended Action
${nextAction}
`;
}
