import { create } from "zustand";
import type { Project, BuildStatus, FindingStatus } from "./types";
import {
  listProjects,
  upsertProject as upsertProjectFn,
  deleteProject as deleteProjectFn,
  seedDemoProjects as seedFn,
  wipeProjects as wipeFn,
} from "./projects.functions";

interface Store {
  projects: Project[];
  loaded: boolean;
  loading: boolean;
  load: () => Promise<void>;
  reset: () => void;
  seedDemo: () => Promise<void>;
  wipeAll: () => Promise<void>;
  updateProject: (id: string, patch: Partial<Project>) => void;
  replaceProject: (project: Project) => void;
  removeProject: (id: string) => Promise<void>;
  toggleBuildPause: (id: string, reason?: string) => void;
  setFindingStatus: (projectId: string, findingId: string, status: FindingStatus) => void;
}

async function persist(project: Project) {
  try {
    await upsertProjectFn({ data: { project } });
  } catch (e) {
    console.error("Failed to persist project", e);
  }
}

export const useStore = create<Store>((set, get) => ({
  projects: [],
  loaded: false,
  loading: false,
  load: async () => {
    if (get().loading) return;
    set({ loading: true });
    try {
      const projects = await listProjects();
      set({ projects, loaded: true, loading: false });
    } catch (e) {
      console.error("Failed to load projects", e);
      set({ loading: false });
    }
  },
  reset: () => set({ projects: [], loaded: false, loading: false }),
  seedDemo: async () => {
    await seedFn({ data: undefined as never });
    await get().load();
  },
  wipeAll: async () => {
    await wipeFn({ data: undefined as never });
    set({ projects: [] });
  },
  updateProject: (id, patch) => {
    let updated: Project | undefined;
    set((s) => ({
      projects: s.projects.map((p) => {
        if (p.id !== id) return p;
        updated = { ...p, ...patch };
        return updated;
      }),
    }));
    if (updated) void persist(updated);
  },
  replaceProject: (project) =>
    set((s) => ({
      projects: s.projects.some((p) => p.id === project.id)
        ? s.projects.map((p) => (p.id === project.id ? project : p))
        : [project, ...s.projects],
    })),
  removeProject: async (id) => {
    set((s) => ({ projects: s.projects.filter((p) => p.id !== id) }));
    await deleteProjectFn({ data: { id } });
  },
  toggleBuildPause: (id, reason) => {
    let updated: Project | undefined;
    set((s) => ({
      projects: s.projects.map((p) => {
        if (p.id !== id) return p;
        const next: BuildStatus = p.buildStatus === "Paused" ? "Building" : "Paused";
        updated = { ...p, buildStatus: next, pauseReason: next === "Paused" ? reason || "Paused by founder" : undefined };
        return updated;
      }),
    }));
    if (updated) void persist(updated);
  },
  setFindingStatus: (projectId, findingId, status) => {
    let updated: Project | undefined;
    set((s) => ({
      projects: s.projects.map((p) => {
        if (p.id !== projectId) return p;
        updated = { ...p, findings: p.findings.map((f) => (f.id === findingId ? { ...f, status } : f)) };
        return updated;
      }),
    }));
    if (updated) void persist(updated);
  },
}));

export const useProject = (id: string) => useStore((s) => s.projects.find((p) => p.id === id));
