export type Stage = "Idea" | "Planning" | "Building" | "Testing" | "Launched" | "Paused";
export type BuildStatus = "Planning" | "Building" | "Paused" | "Blocked" | "Ready" | "Launched";
export type Priority = "Low" | "Medium" | "High" | "Critical";
export type AgentType = "Manager" | "Builder" | "Security" | "Research";
export type AgentStatus = "Running" | "Idle" | "Paused" | "Blocked";
export type YoloMode = "Off" | "Drafting only" | "Build allowed" | "Build + test allowed" | "Preview deploy allowed";
export type TaskStatus = "Backlog" | "In Progress" | "Blocked" | "Review" | "Done";
export type Severity = "Low" | "Medium" | "High" | "Critical";
export type FindingStatus = "Open" | "Fixed" | "Accepted" | "False Positive";

export interface TechStack {
  frontend: string;
  styling: string;
  backend: string;
  database: string;
  auth: string;
  hosting: string;
  design: string;
  rationale: string;
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  type: AgentType;
  provider: string;
  model: string;
  yoloMode: YoloMode;
  status: AgentStatus;
  currentTask: string;
  permissions: string;
  hourlyRate: number;
  hoursUsed: number;
}

export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  priority: Priority;
  owner?: string;
  estimateHours?: number;
  dueDate?: string;
  acceptanceCriteria?: string;
}

export interface Milestone {
  id: string;
  title: string;
  status: "Pending" | "In Progress" | "Complete";
  targetDate: string;
}

export interface SecurityFinding {
  id: string;
  title: string;
  severity: Severity;
  category: string;
  status: FindingStatus;
  recommendation: string;
  owner?: string;
  impact?: string;
  blocksLaunch: boolean;
}

export interface Decision {
  id: string;
  decision: string;
  createdAt: string;
}

export interface ActivityEvent {
  id: string;
  agent: string;
  message: string;
  timestamp: string;
  type?: "build" | "security" | "product" | "system";
}

export interface Project {
  id: string;
  name: string;
  description: string;
  problem: string;
  targetUser: string;
  mvpGoal: string;
  stage: Stage;
  buildStatus: BuildStatus;
  priority: Priority;
  progress: number;
  startedAt?: string;
  deadline: string;
  budget: number;
  stackMonthlyCost: number;
  repo?: string;
  environment?: string;
  buildVelocity: number; // 0-100
  techStack: TechStack;
  agents: Agent[];
  milestones: Milestone[];
  tasks: Task[];
  findings: SecurityFinding[];
  notes: string;
  links: { label: string; url: string }[];
  decisions: Decision[];
  activity: ActivityEvent[];
  pauseReason?: string;
}
