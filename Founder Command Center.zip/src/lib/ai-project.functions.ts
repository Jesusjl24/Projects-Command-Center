import { createServerFn } from "@tanstack/react-start";
import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

const ActionSchema = z.object({
  action: z.enum(["pdr", "sprint", "handoff", "risk"]),
  projectContext: z.string().min(1).max(20000),
});

const PROMPTS: Record<z.infer<typeof ActionSchema>["action"], { system: string; user: (ctx: string) => string }> = {
  pdr: {
    system:
      "You are a senior product manager. Draft a concise Product Design Requirements (PDR) doc in Markdown. Use these sections: Problem, Target user, Core value, MVP scope (bulleted, 5–8 items), Non-goals, Success metrics, Key risks. Be specific and grounded in the context.",
    user: (ctx) => `Draft the PDR for this project.\n\n${ctx}`,
  },
  sprint: {
    system:
      "You are a solo-founder AI chief of staff. Propose the next 1-week sprint. Output Markdown with: Sprint goal (1 sentence), Ranked backlog (5–7 tasks with owner suggestion + rough effort in hours), Definition of done, Risks to watch. Ground everything in current tasks, agents, findings, and deadline in the context. Do not invent.",
    user: (ctx) => `Propose the next sprint.\n\n${ctx}`,
  },
  handoff: {
    system:
      "You are a technical writer preparing an AI-builder handoff. Produce a tight Markdown brief a coding agent could execute against: Context (2 sentences), Current state, Next 3 concrete build tasks with acceptance criteria, Known blockers, Files/areas to touch (best guess based on stack).",
    user: (ctx) => `Draft the builder handoff notes.\n\n${ctx}`,
  },
  risk: {
    system:
      "You are a launch risk auditor. Review the project and output Markdown with: Launch readiness verdict (Ready / At risk / Not ready) + 1 sentence, Top 3 blockers (each with why + fix), Budget/timeline pressure note, Security posture note referencing open findings. Be direct.",
    user: (ctx) => `Run the launch risk review.\n\n${ctx}`,
  },
};

export const runProjectAiAction = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => ActionSchema.parse(input))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");

    const gateway = createLovableAiGatewayProvider(key);
    const model = gateway("google/gemini-3-flash-preview");
    const { system, user } = PROMPTS[data.action];

    const { text } = await generateText({
      model,
      system,
      prompt: user(data.projectContext),
    });

    return { text };
  });
