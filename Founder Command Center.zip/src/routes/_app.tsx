import { createFileRoute, Outlet, useRouterState, Link, Navigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { CommandPalette, useCommandPalette } from "@/components/layout/CommandPalette";
import { Search, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/_app")({
  component: AppLayout,
});

const PAGE_TITLES: Record<string, string> = {
  overview: "Overview",
  projects: "Projects",
  copilot: "Copilot",
  agents: "Agents",
  security: "Security",
  analytics: "Analytics",
  settings: "Settings",
};

function AppLayout() {
  const { open, setOpen } = useCommandPalette();
  const { session, loading } = useAuth();
  const loadProjects = useStore((s) => s.load);
  const resetStore = useStore((s) => s.reset);
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const segments = pathname.split("/").filter(Boolean);
  const section = segments[0] ? PAGE_TITLES[segments[0]] ?? segments[0] : "Overview";
  const isDetail = segments[0] === "projects" && segments[1];

  useEffect(() => {
    if (session) {
      void loadProjects();
    } else {
      resetStore();
    }
  }, [session, loadProjects, resetStore]);

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center bg-background">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (!session) return <Navigate to="/auth" />;


  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <AppSidebar />
        <SidebarInset className="flex-1 min-w-0">
          <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-border/60 bg-background/80 px-4 backdrop-blur">
            <SidebarTrigger className="text-muted-foreground hover:text-foreground" />
            <div className="hidden min-w-0 items-center gap-1.5 text-xs text-muted-foreground sm:flex">
              <Link to="/overview" className="hover:text-foreground">Command Center</Link>
              <span className="text-border">/</span>
              {isDetail ? (
                <>
                  <Link to="/projects" className="hover:text-foreground">Projects</Link>
                  <span className="text-border">/</span>
                  <span className="truncate text-foreground">Detail</span>
                </>
              ) : (
                <span className="truncate text-foreground">{section}</span>
              )}
            </div>
            <div className="ml-auto flex items-center gap-3">
              <button
                type="button"
                onClick={() => setOpen(true)}
                className="group inline-flex items-center gap-2 rounded-md border border-border/70 bg-panel-elevated px-2.5 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
                aria-label="Open command palette"
              >
                <Search className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Jump to…</span>
                <kbd className="hidden rounded border border-border/70 bg-background px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground sm:inline">
                  ⌘K
                </kbd>
              </button>
              <div className="hidden items-center gap-2 md:flex">
                <div className="h-2 w-2 rounded-full bg-success animate-pulse" />
                <span className="text-xs text-muted-foreground">synced</span>
              </div>
            </div>
          </header>
          <main className="flex-1 p-4 sm:p-6 lg:p-8">
            <Outlet />
          </main>
        </SidebarInset>
      </div>
      <CommandPalette open={open} onOpenChange={setOpen} />
    </SidebarProvider>
  );
}
