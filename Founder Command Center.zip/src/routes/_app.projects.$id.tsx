import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { useProject, useStore } from "@/lib/store";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { ActivityStream } from "@/components/ui/ActivityStream";
import { MetricCard } from "@/components/ui/MetricCard";
import { analytics, money, healthScore, launchReadiness, generateHandoff, daysRemaining } from "@/lib/analytics";
import { runProjectAiAction } from "@/lib/ai-project.functions";
import { listAgentRuns, runAgentTurn, type AgentRun } from "@/lib/agent-runs.functions";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { ArrowLeft, Copy, Pause, Play, ShieldCheck, Pencil, DollarSign, Server, CalendarClock, TrendingUp, Sparkles, FileText, ListChecks, PackageCheck, AlertTriangle, Loader2, Zap, Bot } from "lucide-react";
import type { AgentType, Project } from "@/lib/types";

export const Route = createFileRoute("/_app/projects/$id")({
  head: ({ params }) => ({
    meta: [
      { title: `${params.id} — Command Center` },
      { name: "description", content: "Project command page: mission, stack, agents, build, security, handoff." },
    ],
  }),
  component: ProjectDetailPage,
  notFoundComponent: () => (
    <div className="panel p-8 text-center">
      <h1 className="text-lg font-semibold text-foreground">Project not found</h1>
      <Link to="/projects" className="mt-2 inline-block text-sm text-primary hover:underline">Back to projects</Link>
    </div>
  ),
});

function ProjectDetailPage() {
  const { id } = Route.useParams();
  const project = useProject(id);
  const toggleBuild = useStore((s) => s.toggleBuildPause);
  const router = useRouter();

  if (!project) {
    return (
      <div className="panel p-8 text-center">
        <h1 className="text-lg font-semibold text-foreground">Project not found</h1>
        <Link to="/projects" className="mt-2 inline-block text-sm text-primary hover:underline">Back to projects</Link>
      </div>
    );
  }

  const a = analytics(project);
  const hs = healthScore(project);
  const lr = launchReadiness(project);
  const isPaused = project.buildStatus === "Paused";

  const copyHandoff = async () => {
    const md = generateHandoff(project);
    try {
      await navigator.clipboard.writeText(md);
      toast.success("Handoff package copied to clipboard");
    } catch {
      toast.error("Copy failed — select the preview text below instead.");
    }
  };

  return (
    <div className="space-y-6">
      <button
        onClick={() => router.history.back()}
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Back
      </button>

      {/* HERO */}
      <div className="panel p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap gap-1.5">
              <StatusBadge kind="stage" value={project.stage} />
              <StatusBadge kind="build" value={project.buildStatus} />
              <StatusBadge kind="priority" value={project.priority} />
            </div>
            <h1 className="mt-3 text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">{project.name}</h1>
            <p className="mt-2 max-w-3xl text-sm text-muted-foreground">{project.description}</p>
            <div className="mt-4 max-w-md">
              <div className="mb-1 flex items-baseline justify-between text-xs">
                <span className="text-muted-foreground">Build progress</span>
                <span className="font-medium text-foreground">{project.progress}%</span>
              </div>
              <ProgressBar value={project.progress} />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => toggleBuild(project.id)}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-panel px-3 py-2 text-sm font-medium text-foreground hover:bg-panel-elevated"
            >
              {isPaused ? <><Play className="h-4 w-4" /> Resume build</> : <><Pause className="h-4 w-4" /> Pause build</>}
            </button>
            <button
              onClick={copyHandoff}
              className="inline-flex items-center gap-1.5 rounded-md gradient-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
            >
              <Copy className="h-4 w-4" /> Copy handoff
            </button>
            <button
              onClick={() => toast.info("Security review will run when Sentinel is wired up.")}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-panel px-3 py-2 text-sm font-medium text-foreground hover:bg-panel-elevated"
            >
              <ShieldCheck className="h-4 w-4" /> Run security review
            </button>
            <button
              onClick={() => toast.info("Inline editing coming with persistence.")}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-panel px-3 py-2 text-sm font-medium text-foreground hover:bg-panel-elevated"
            >
              <Pencil className="h-4 w-4" /> Edit
            </button>
          </div>
        </div>
      </div>

      {/* BUILD SNAPSHOT */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <MetricCard label="Est. total" value={money(project.budget)} icon={DollarSign} accent="info" />
        <MetricCard label="Monthly stack" value={money(project.stackMonthlyCost)} icon={Server} accent="primary" />
        <MetricCard label="Deadline" value={project.deadline} icon={CalendarClock} accent="warning" hint={`${daysRemaining(project.deadline)} days remaining`} />
        <MetricCard label="Progress" value={`${project.progress}%`} icon={TrendingUp} accent="success" />
      </div>

      {/* TABS */}
      <Tabs defaultValue="overview" className="w-full">
        <div className="overflow-x-auto">
          <TabsList className="w-max">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="mission">Mission</TabsTrigger>
            <TabsTrigger value="stack">Stack</TabsTrigger>
            <TabsTrigger value="agents">Agents</TabsTrigger>
            <TabsTrigger value="build">Build</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="handoff">Handoff</TabsTrigger>
            <TabsTrigger value="ai">AI actions</TabsTrigger>
            <TabsTrigger value="runs">Runs</TabsTrigger>
          </TabsList>
        </div>

        {/* Overview */}
        <TabsContent value="overview" className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <MetricCard label="Health" value={`${hs}%`} accent={hs > 70 ? "success" : hs > 40 ? "primary" : "danger"} />
            <MetricCard label="Launch readiness" value={`${lr}%`} accent="primary" />
            <MetricCard label="Spent" value={money(a.spent)} accent="info" />
            <MetricCard label="Remaining budget" value={money(a.remaining)} accent="success" />
            <MetricCard label="Elapsed days" value={a.elapsedDays} accent="info" />
            <MetricCard label="Days left" value={a.remainingDays} accent={a.remainingDays < 7 ? "warning" : "primary"} />
            <MetricCard label="Build velocity" value={`${project.buildVelocity}%`} accent="primary" />
            <MetricCard label="Budget pressure" value={`${a.budgetPressure}%`} accent={a.budgetPressure > 80 ? "danger" : "info"} />
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <div className="panel p-5 lg:col-span-2">
              <h3 className="mb-3 text-sm font-semibold text-foreground">Cost breakdown</h3>
              <div className="space-y-3">
                <BreakdownRow label="Agents" value={a.agentSpent} total={project.budget} tone="primary" />
                <BreakdownRow label="Stack (elapsed)" value={a.stackSpent} total={project.budget} tone="primary" />
                <BreakdownRow label="Remaining budget" value={a.remaining} total={project.budget} tone="success" />
              </div>
              <div className="mt-6">
                <h4 className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Timeline</h4>
                <ol className="space-y-2 text-sm">
                  {project.milestones.map((m) => (
                    <li key={m.id} className="flex items-center justify-between rounded-md border border-border/60 px-3 py-2">
                      <span className="text-foreground">{m.title}</span>
                      <span className="flex items-center gap-2 text-xs text-muted-foreground">
                        {m.targetDate} · <span className={m.status === "Complete" ? "text-success" : m.status === "In Progress" ? "text-info" : ""}>{m.status}</span>
                      </span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
            <div className="panel p-5">
              <h3 className="mb-3 text-sm font-semibold text-foreground">AI activity</h3>
              <ActivityStream events={project.activity} />
              <div className="mt-5 rounded-lg border border-warning/30 bg-warning/5 p-3">
                <div className="text-xs font-medium uppercase tracking-wider text-warning">Launch risk</div>
                <p className="mt-1 text-sm text-foreground">
                  {project.findings.filter((f) => f.status === "Open" && (f.severity === "High" || f.severity === "Critical")).length} blocking finding(s), {project.tasks.filter((t) => t.status === "Blocked").length} blocked task(s).
                </p>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Mission */}
        <TabsContent value="mission" className="mt-4">
          <div className="panel space-y-5 p-5">
            <Field label="Problem">{project.problem}</Field>
            <Field label="Target user">{project.targetUser}</Field>
            <Field label="MVP goal">{project.mvpGoal}</Field>
            <Field label="Notes">{project.notes || "—"}</Field>
            <div>
              <div className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Decisions</div>
              {project.decisions.length === 0 ? (
                <p className="text-sm text-muted-foreground">No decisions logged.</p>
              ) : (
                <ul className="space-y-2 text-sm">
                  {project.decisions.map((d) => (
                    <li key={d.id} className="rounded-md border border-border/60 px-3 py-2">
                      <span className="text-foreground">{d.decision}</span>
                      <span className="ml-2 text-xs text-muted-foreground">({d.createdAt})</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </TabsContent>

        {/* Stack */}
        <TabsContent value="stack" className="mt-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="panel space-y-3 p-5">
              <StackRow label="Frontend" value={project.techStack.frontend} />
              <StackRow label="Styling" value={project.techStack.styling} />
              <StackRow label="Backend" value={project.techStack.backend} />
              <StackRow label="Database" value={project.techStack.database} />
              <StackRow label="Auth" value={project.techStack.auth} />
              <StackRow label="Hosting" value={project.techStack.hosting} />
              <StackRow label="Design" value={project.techStack.design} />
            </div>
            <div className="panel space-y-3 p-5">
              <Field label="Rationale">{project.techStack.rationale}</Field>
              <StackRow label="Budget" value={money(project.budget)} />
              <StackRow label="Monthly stack cost" value={money(project.stackMonthlyCost)} />
              <StackRow label="Start date" value={project.startedAt || "—"} />
              <StackRow label="Deadline" value={project.deadline} />
            </div>
          </div>
        </TabsContent>

        {/* Agents */}
        <TabsContent value="agents" className="mt-4">
          <div className="panel overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Agent</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Provider</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>YOLO</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Cost</TableHead>
                  <TableHead className="text-right">Hours</TableHead>
                  <TableHead>Current task</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {project.agents.map((ag) => (
                  <TableRow key={ag.id}>
                    <TableCell className="font-medium text-foreground">{ag.name}</TableCell>
                    <TableCell className="text-muted-foreground">{ag.role}</TableCell>
                    <TableCell className="text-muted-foreground">{ag.provider}</TableCell>
                    <TableCell className="text-muted-foreground">{ag.model}</TableCell>
                    <TableCell><span className="text-xs text-muted-foreground">{ag.yoloMode}</span></TableCell>
                    <TableCell><StatusBadge kind="agent" value={ag.status} /></TableCell>
                    <TableCell className="text-right text-foreground">{money(ag.hourlyRate * ag.hoursUsed)}</TableCell>
                    <TableCell className="text-right text-muted-foreground">{ag.hoursUsed}</TableCell>
                    <TableCell className="max-w-xs text-xs text-muted-foreground">{ag.currentTask}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* Build */}
        <TabsContent value="build" className="mt-4 space-y-4">
          <div className="panel p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <StatusBadge kind="build" value={project.buildStatus} />
                {isPaused && project.pauseReason && (
                  <span className="text-xs text-warning">Pause reason: {project.pauseReason}</span>
                )}
              </div>
              <button
                onClick={() => toggleBuild(project.id)}
                className="inline-flex items-center gap-1.5 rounded-md border border-border bg-panel px-3 py-1.5 text-xs font-medium text-foreground hover:bg-panel-elevated"
              >
                {isPaused ? <><Play className="h-3.5 w-3.5" /> Resume</> : <><Pause className="h-3.5 w-3.5" /> Pause</>}
              </button>
            </div>
          </div>

          <div className="panel overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Task</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Owner</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {project.tasks.map((t) => (
                  <TableRow key={t.id}>
                    <TableCell className="font-medium text-foreground">{t.title}</TableCell>
                    <TableCell><StatusBadge kind="task" value={t.status} /></TableCell>
                    <TableCell><StatusBadge kind="priority" value={t.priority} /></TableCell>
                    <TableCell className="text-muted-foreground">{t.owner || "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* Security */}
        <TabsContent value="security" className="mt-4">
          <div className="panel p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-foreground">Launch risk review</h3>
                <p className="text-xs text-muted-foreground">
                  {project.findings.filter((f) => f.status === "Open").length} open ·{" "}
                  {project.findings.filter((f) => f.status === "Open" && (f.severity === "High" || f.severity === "Critical")).length} blocking
                </p>
              </div>
              <button
                onClick={() => toast.info("Manual finding entry coming soon.")}
                className="rounded-md border border-border bg-panel px-3 py-1.5 text-xs font-medium text-foreground hover:bg-panel-elevated"
              >
                Add finding
              </button>
            </div>

            {project.findings.length === 0 ? (
              <p className="text-sm text-muted-foreground">No security findings yet.</p>
            ) : (
              <SecurityList projectId={project.id} findings={project.findings} />
            )}
          </div>
        </TabsContent>

        {/* Activity */}
        <TabsContent value="activity" className="mt-4">
          <div className="panel p-5">
            <ActivityStream events={project.activity} />
          </div>
        </TabsContent>

        {/* Handoff */}
        <TabsContent value="handoff" className="mt-4">
          <div className="panel p-5">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-foreground">Handoff package</h3>
                <p className="text-xs text-muted-foreground">Copy the markdown or paste it into a hand-off doc.</p>
              </div>
              <button
                onClick={copyHandoff}
                className="inline-flex items-center gap-1.5 rounded-md gradient-primary px-3 py-1.5 text-xs font-medium text-primary-foreground hover:opacity-90"
              >
                <Copy className="h-3.5 w-3.5" /> Copy markdown
              </button>
            </div>
            <pre className="max-h-[600px] overflow-auto rounded-lg border border-border/60 bg-panel-elevated p-4 text-xs leading-relaxed text-muted-foreground">
{generateHandoff(project)}
            </pre>
          </div>
        </TabsContent>

        {/* AI Actions */}
        <TabsContent value="ai" className="mt-4">
          <AiActionsPanel project={project} />
        </TabsContent>

        {/* Agent Runs */}
        <TabsContent value="runs" className="mt-4">
          <AgentRunsPanel project={project} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

type AiAction = "pdr" | "sprint" | "handoff" | "risk";

const AI_ACTIONS: { key: AiAction; label: string; description: string; icon: typeof Sparkles }[] = [
  { key: "pdr", label: "Generate PDR", description: "Draft a full Product Design Requirements doc.", icon: FileText },
  { key: "sprint", label: "Suggest next sprint", description: "Rank the next 1-week backlog for this project.", icon: ListChecks },
  { key: "handoff", label: "Draft builder handoff", description: "Tight brief a coding agent can execute against.", icon: PackageCheck },
  { key: "risk", label: "Launch risk review", description: "Verdict + top blockers grounded in current findings.", icon: AlertTriangle },
];

function AiActionsPanel({ project }: { project: Project }) {
  const runAction = useServerFn(runProjectAiAction);
  const [loading, setLoading] = useState<AiAction | null>(null);
  const [active, setActive] = useState<AiAction | null>(null);
  const [output, setOutput] = useState<string>("");

  const run = async (action: AiAction) => {
    setLoading(action);
    setActive(action);
    setOutput("");
    try {
      const res = await runAction({ data: { action, projectContext: generateHandoff(project) } });
      setOutput(res.text);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "AI action failed";
      toast.error(msg);
      setOutput("");
    } finally {
      setLoading(null);
    }
  };

  const copy = async () => {
    if (!output) return;
    try {
      await navigator.clipboard.writeText(output);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Copy failed");
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {AI_ACTIONS.map(({ key, label, description, icon: Icon }) => {
          const isLoading = loading === key;
          const isActive = active === key;
          return (
            <button
              key={key}
              onClick={() => run(key)}
              disabled={loading !== null}
              className={`panel group flex flex-col items-start gap-2 p-4 text-left transition hover:border-primary/50 disabled:cursor-not-allowed disabled:opacity-60 ${isActive ? "border-primary/60" : ""}`}
            >
              <div className="flex items-center gap-2">
                <span className="rounded-md gradient-primary p-1.5 text-primary-foreground">
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Icon className="h-4 w-4" />}
                </span>
                <span className="text-sm font-semibold text-foreground">{label}</span>
              </div>
              <p className="text-xs text-muted-foreground">{description}</p>
            </button>
          );
        })}
      </div>

      <div className="panel p-5">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">
              {active ? AI_ACTIONS.find((a) => a.key === active)?.label : "AI output"}
            </h3>
          </div>
          {output && (
            <button
              onClick={copy}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-panel px-3 py-1.5 text-xs font-medium text-foreground hover:bg-panel-elevated"
            >
              <Copy className="h-3.5 w-3.5" /> Copy
            </button>
          )}
        </div>
        {loading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Generating with Lovable AI…
          </div>
        ) : output ? (
          <pre className="max-h-[600px] overflow-auto whitespace-pre-wrap rounded-lg border border-border/60 bg-panel-elevated p-4 text-xs leading-relaxed text-foreground">
{output}
          </pre>
        ) : (
          <p className="text-sm text-muted-foreground">
            Pick an action above. Output is grounded in this project's current stage, tasks, agents, budget, and security findings.
          </p>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1 text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-sm text-foreground">{children}</div>
    </div>
  );
}

function StackRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between border-b border-border/40 pb-2 last:border-b-0 last:pb-0">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      <span className="text-sm font-medium text-foreground">{value}</span>
    </div>
  );
}

function BreakdownRow({ label, value, total, tone }: { label: string; value: number; total: number; tone: "primary" | "success" | "warning" | "danger" }) {
  const pct = Math.round((value / Math.max(1, total)) * 100);
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium text-foreground">{money(value)} · {pct}%</span>
      </div>
      <ProgressBar value={pct} tone={tone} />
    </div>
  );
}

function SecurityList({ projectId, findings }: { projectId: string; findings: import("@/lib/types").SecurityFinding[] }) {
  const setStatus = useStore((s) => s.setFindingStatus);
  return (
    <ul className="space-y-3">
      {findings.map((f) => (
        <li key={f.id} className="rounded-lg border border-border/60 p-4">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <StatusBadge kind="severity" value={f.severity} />
                <StatusBadge kind="finding" value={f.status} />
                <span className="text-xs text-muted-foreground">{f.category}</span>
                {f.blocksLaunch && <span className="text-xs font-medium text-destructive">Blocks launch</span>}
              </div>
              <div className="mt-2 font-medium text-foreground">{f.title}</div>
              <p className="mt-1 text-sm text-muted-foreground">{f.recommendation}</p>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button onClick={() => setStatus(projectId, f.id, "Fixed")} className="rounded-md border border-border bg-panel px-2 py-1 text-[11px] text-foreground hover:bg-panel-elevated">Mark fixed</button>
              <button onClick={() => setStatus(projectId, f.id, "Accepted")} className="rounded-md border border-border bg-panel px-2 py-1 text-[11px] text-foreground hover:bg-panel-elevated">Accept</button>
              <button onClick={() => setStatus(projectId, f.id, "False Positive")} className="rounded-md border border-border bg-panel px-2 py-1 text-[11px] text-foreground hover:bg-panel-elevated">False positive</button>
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}

const AGENT_TURN_TYPES: { key: AgentType; label: string; hint: string }[] = [
  { key: "Manager", label: "Manager", hint: "Advances tasks and posts a status note." },
  { key: "Builder", label: "Builder", hint: "Moves build tasks, proposes new work." },
  { key: "Security", label: "Security", hint: "Reviews launch risk, may add findings." },
  { key: "Research", label: "Research", hint: "Posts a short research note." },
];

function AgentRunsPanel({ project }: { project: Project }) {
  const replaceProject = useStore((s) => s.replaceProject);
  const runTurn = useServerFn(runAgentTurn);
  const listRuns = useServerFn(listAgentRuns);
  const [selected, setSelected] = useState<AgentType>("Manager");
  const [loading, setLoading] = useState(false);
  const [runs, setRuns] = useState<AgentRun[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  const refresh = async () => {
    try {
      const rows = await listRuns({ data: { projectId: project.id } });
      setRuns(rows);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to load runs";
      toast.error(msg);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    void refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [project.id]);

  const trigger = async () => {
    setLoading(true);
    try {
      const res = await runTurn({ data: { projectId: project.id, agentType: selected } });
      replaceProject(res.project);
      toast.success(`${res.run.agentName} took a turn`);
      await refresh();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Agent run failed";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="panel p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-foreground">Run an agent turn</h3>
            <p className="mt-1 text-xs text-muted-foreground">
              Kicks off an AI agent grounded in this project's current state. Applies task, finding, and activity updates.
            </p>
          </div>
          <button
            onClick={trigger}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-md gradient-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
            {loading ? "Running…" : `Run ${selected} turn`}
          </button>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {AGENT_TURN_TYPES.map((a) => (
            <button
              key={a.key}
              onClick={() => setSelected(a.key)}
              disabled={loading}
              className={`rounded-lg border p-3 text-left text-sm transition ${
                selected === a.key
                  ? "border-primary/60 bg-primary/5 text-foreground"
                  : "border-border/60 bg-panel-elevated text-muted-foreground hover:text-foreground"
              }`}
            >
              <div className="flex items-center gap-2 font-medium">
                <Bot className="h-3.5 w-3.5" /> {a.label}
              </div>
              <div className="mt-1 text-[11px] leading-snug">{a.hint}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="panel p-5">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-foreground">Run history</h3>
          <span className="text-xs text-muted-foreground">{runs.length} run{runs.length === 1 ? "" : "s"}</span>
        </div>
        {loadingHistory ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading…
          </div>
        ) : runs.length === 0 ? (
          <p className="text-sm text-muted-foreground">No agent runs yet. Trigger one above.</p>
        ) : (
          <ul className="space-y-3">
            {runs.map((r) => (
              <li key={r.id} className="rounded-lg border border-border/60 p-4">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded-md bg-primary/10 px-2 py-0.5 text-[11px] font-medium text-primary">
                      {r.agentType}
                    </span>
                    <span className="text-sm font-medium text-foreground">{r.agentName}</span>
                  </div>
                  <span className="text-[11px] text-muted-foreground">
                    {new Date(r.createdAt).toLocaleString()}
                    {r.model ? ` · ${r.model}` : ""}
                  </span>
                </div>
                <p className="mt-2 text-sm text-foreground">{r.summary}</p>
                <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-muted-foreground">
                  <span className="rounded bg-panel-elevated px-2 py-0.5">{r.applied.taskUpdates} task update(s)</span>
                  <span className="rounded bg-panel-elevated px-2 py-0.5">{r.applied.newTasks} new task(s)</span>
                  <span className="rounded bg-panel-elevated px-2 py-0.5">{r.applied.newFindings} new finding(s)</span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
