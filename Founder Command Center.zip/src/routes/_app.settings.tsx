import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Settings as SettingsIcon, User, Bot, Shield, Download, Save, Database, LogOut } from "lucide-react";
import type { YoloMode } from "@/lib/types";
import { useStore } from "@/lib/store";
import { generateHandoff } from "@/lib/analytics";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_app/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Command Center" },
      { name: "description", content: "Workspace, autonomy, model, and export settings." },
    ],
  }),
  component: SettingsPage,
});

const YOLO_MODES: YoloMode[] = ["Off", "Drafting only", "Build allowed", "Build + test allowed", "Preview deploy allowed"];
const PROVIDERS = ["Claude", "OpenAI", "Gemini", "Local"] as const;

function SettingsPage() {
  const projects = useStore((s) => s.projects);
  const seedDemo = useStore((s) => s.seedDemo);
  const wipeAll = useStore((s) => s.wipeAll);
  const { session } = useAuth();
  const navigate = useNavigate();
  const [workspace, setWorkspace] = useState("Founder Studio");
  const [founder, setFounder] = useState(session?.user.email ?? "Alex Chen");
  const [timezone, setTimezone] = useState("America/Los_Angeles");
  const [defaultYolo, setDefaultYolo] = useState<YoloMode>("Build + test allowed");
  const [defaultProvider, setDefaultProvider] = useState<(typeof PROVIDERS)[number]>("Claude");
  const [autoPause, setAutoPause] = useState(true);
  const [blockOnCritical, setBlockOnCritical] = useState(true);
  const [dailyDigest, setDailyDigest] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const save = () => toast.success("Settings saved.");

  const handleSeed = async () => {
    setBusy("seed");
    try {
      await seedDemo();
      toast.success("Demo portfolio loaded.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to seed");
    } finally {
      setBusy(null);
    }
  };

  const handleWipe = async () => {
    if (!confirm("Delete all your projects? This cannot be undone.")) return;
    setBusy("wipe");
    try {
      await wipeAll();
      toast.success("Portfolio cleared.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to wipe");
    } finally {
      setBusy(null);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  };

  const exportPortfolio = () => {
    const md = projects.map((p) => generateHandoff(p)).join("\n\n---\n\n");
    const blob = new Blob([md], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "portfolio-handoff.md";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Exported portfolio handoff.");
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(projects, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "portfolio.json";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Exported portfolio JSON.");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Settings</h1>
          <p className="mt-1 text-sm text-muted-foreground">Workspace, autonomy defaults, safety, and exports.</p>
        </div>
        <button
          onClick={save}
          className="inline-flex items-center gap-1.5 rounded-md gradient-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          <Save className="h-4 w-4" /> Save changes
        </button>
      </div>

      <Section icon={User} title="Workspace">
        <Field label="Workspace name">
          <TextInput value={workspace} onChange={setWorkspace} />
        </Field>
        <Field label="Founder name">
          <TextInput value={founder} onChange={setFounder} />
        </Field>
        <Field label="Timezone">
          <TextInput value={timezone} onChange={setTimezone} />
        </Field>
      </Section>

      <Section icon={Bot} title="Agent defaults">
        <Field label="Default YOLO mode" help="Applied to new agents when a project is created.">
          <SelectInput value={defaultYolo} onChange={(v) => setDefaultYolo(v as YoloMode)} options={YOLO_MODES} />
        </Field>
        <Field label="Preferred provider">
          <SelectInput
            value={defaultProvider}
            onChange={(v) => setDefaultProvider(v as (typeof PROVIDERS)[number])}
            options={PROVIDERS as unknown as string[]}
          />
        </Field>
        <Field label="Auto-pause on blockers" help="Pause build agents automatically when a task is Blocked.">
          <Toggle checked={autoPause} onChange={setAutoPause} />
        </Field>
      </Section>

      <Section icon={Shield} title="Safety">
        <Field label="Block launch on Critical findings" help="Sentinel will prevent Ready → Launched transitions.">
          <Toggle checked={blockOnCritical} onChange={setBlockOnCritical} />
        </Field>
        <Field label="Daily portfolio digest" help="Mira PM sends a morning summary of blockers and next actions.">
          <Toggle checked={dailyDigest} onChange={setDailyDigest} />
        </Field>
      </Section>

      <Section icon={Download} title="Export">
        <p className="mb-3 text-sm text-muted-foreground">
          Portfolio state is local demo data. Export snapshots for handoff or backup.
        </p>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={exportPortfolio}
            className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-panel-elevated px-3 py-2 text-sm text-foreground hover:border-primary/40"
          >
            <Download className="h-4 w-4" /> Portfolio handoff (.md)
          </button>
          <button
            onClick={exportJson}
            className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-panel-elevated px-3 py-2 text-sm text-foreground hover:border-primary/40"
          >
            <Download className="h-4 w-4" /> Raw state (.json)
          </button>
        </div>
      </Section>

      <Section icon={Database} title="Data">
        <p className="mb-3 text-sm text-muted-foreground md:col-span-2">
          Your projects live in Lovable Cloud, scoped to your account. Seed the demo portfolio to explore, or clear it to start clean.
        </p>
        <div className="flex flex-wrap gap-2 md:col-span-2">
          <button
            onClick={handleSeed}
            disabled={busy === "seed"}
            className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-panel-elevated px-3 py-2 text-sm text-foreground hover:border-primary/40 disabled:opacity-50"
          >
            <Database className="h-4 w-4" /> Load demo portfolio
          </button>
          <button
            onClick={handleWipe}
            disabled={busy === "wipe"}
            className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-panel-elevated px-3 py-2 text-sm text-destructive hover:border-destructive/60 disabled:opacity-50"
          >
            Delete all projects
          </button>
        </div>
      </Section>

      <Section icon={LogOut} title="Account">
        <div className="md:col-span-2 flex flex-wrap items-center justify-between gap-3">
          <div className="text-sm text-muted-foreground">Signed in as {session?.user.email ?? "unknown"}</div>
          <button
            onClick={signOut}
            className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-panel-elevated px-3 py-2 text-sm text-foreground hover:border-primary/40"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      </Section>

      <div className="panel flex items-start gap-3 p-4 text-xs text-muted-foreground">
        <SettingsIcon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <p>
          Portfolio data is persisted in Lovable Cloud with row-level security. Real agent orchestration ships in the next phase.
        </p>
      </div>
    </div>
  );
}

function Section({ icon: Icon, title, children }: { icon: typeof User; title: string; children: React.ReactNode }) {
  return (
    <section className="panel p-5">
      <div className="mb-4 flex items-center gap-2">
        <Icon className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-semibold text-foreground">{title}</h2>
      </div>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">{children}</div>
    </section>
  );
}

function Field({ label, help, children }: { label: string; help?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</span>
      {children}
      {help ? <span className="mt-1 block text-[11px] text-muted-foreground">{help}</span> : null}
    </label>
  );
}

function TextInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full rounded-md border border-border/70 bg-panel-elevated px-3 py-2 text-sm text-foreground focus:border-primary/60 focus:outline-none"
    />
  );
}

function SelectInput({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full rounded-md border border-border/70 bg-panel-elevated px-3 py-2 text-sm text-foreground focus:border-primary/60 focus:outline-none"
    >
      {options.map((o) => (
        <option key={o} value={o}>{o}</option>
      ))}
    </select>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition ${checked ? "bg-primary" : "bg-panel-elevated border border-border/70"}`}
    >
      <span
        className={`inline-block h-4 w-4 transform rounded-full bg-background transition ${checked ? "translate-x-6" : "translate-x-1"}`}
      />
    </button>
  );
}
