import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState, useEffect } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useStore } from "@/lib/store";
import { analytics, launchReadiness, money, daysRemaining } from "@/lib/analytics";
import type { Project } from "@/lib/types";
import { Sparkles, Send, Loader2, User, Bot, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/copilot")({
  head: () => ({
    meta: [
      { title: "AI Copilot — Command Center" },
      { name: "description", content: "Chat with an AI Copilot that knows your entire portfolio." },
    ],
  }),
  component: CopilotPage,
});

function buildContext(projects: Project[]): string {
  return projects
    .map((p) => {
      const a = analytics(p);
      const openFindings = p.findings.filter((f) => f.status === "Open");
      const openTasks = p.tasks.filter((t) => t.status !== "Done").slice(0, 5);
      return [
        `PROJECT: ${p.name} (id: ${p.id})`,
        `- Stage: ${p.stage} · Build: ${p.buildStatus} · Priority: ${p.priority} · Progress: ${p.progress}%`,
        `- Deadline: ${p.deadline} (${daysRemaining(p.deadline)}d) · Readiness: ${launchReadiness(p)}%`,
        `- Budget: ${money(a.spent)} spent of ${money(p.budget)} (${a.budgetPressure}%) · Stack: ${money(p.stackMonthlyCost)}/mo`,
        `- MVP: ${p.mvpGoal}`,
        `- Agents: ${p.agents.map((ag) => `${ag.name} (${ag.role}, ${ag.status})`).join("; ")}`,
        openFindings.length
          ? `- Open findings: ${openFindings.map((f) => `[${f.severity}] ${f.title}${f.blocksLaunch ? " (BLOCKS LAUNCH)" : ""}`).join("; ")}`
          : "- Open findings: none",
        openTasks.length
          ? `- Open tasks: ${openTasks.map((t) => `[${t.status}/${t.priority}] ${t.title}`).join("; ")}`
          : "- Open tasks: none",
      ].join("\n");
    })
    .join("\n\n");
}

const SUGGESTIONS = [
  "What are my top 3 priorities today?",
  "Which project is most at risk of missing its deadline?",
  "Draft a 1-week sprint plan for the highest priority project.",
  "Summarize open security findings that block launch.",
];

function CopilotPage() {
  const projects = useStore((s) => s.projects);
  const context = useMemo(() => buildContext(projects), [projects]);

  const transport = useMemo(
    () => new DefaultChatTransport({ api: "/api/chat", body: { context } }),
    [context],
  );

  const { messages, sendMessage, status, error } = useChat({
    transport,
    onError: (e) => toast.error(e.message || "Copilot request failed"),
  });

  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const isLoading = status === "submitted" || status === "streaming";

  useEffect(() => {
    inputRef.current?.focus();
  }, []);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  const submit = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || isLoading) return;
    setInput("");
    await sendMessage({ text: trimmed });
    setTimeout(() => inputRef.current?.focus(), 0);
  };

  return (
    <div className="flex h-[calc(100vh-6rem)] flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
            <span className="grid h-8 w-8 place-items-center rounded-lg gradient-primary">
              <Sparkles className="h-4 w-4 text-primary-foreground" />
            </span>
            AI Copilot
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Portfolio-aware. Sees every project, agent, finding, and deadline.
          </p>
        </div>
        <span className="rounded-full border border-border/60 bg-panel-elevated px-3 py-1 text-[11px] text-muted-foreground">
          {projects.length} projects in context
        </span>
      </div>

      <div className="panel flex flex-1 flex-col overflow-hidden p-0">
        <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto p-5">
          {messages.length === 0 ? (
            <EmptyState onPick={submit} />
          ) : (
            messages.map((m) => <MessageBubble key={m.id} message={m} />)
          )}
          {status === "submitted" && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Loader2 className="h-3.5 w-3.5 animate-spin" /> Copilot is thinking…
            </div>
          )}
          {error && (
            <div className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error.message}</span>
            </div>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void submit(input);
          }}
          className="border-t border-border/60 bg-panel-elevated/50 p-3"
        >
          <div className="flex items-end gap-2 rounded-lg border border-border/70 bg-background p-2 focus-within:border-primary/60">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void submit(input);
                }
              }}
              rows={1}
              placeholder="Ask about priorities, risks, or draft a plan…"
              className="max-h-40 min-h-[2.25rem] flex-1 resize-none bg-transparent px-2 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="inline-flex h-9 w-9 items-center justify-center rounded-md gradient-primary text-primary-foreground disabled:opacity-40"
            >
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </button>
          </div>
          <div className="mt-1 px-1 text-[11px] text-muted-foreground">
            Enter to send · Shift+Enter for newline · Powered by Lovable AI
          </div>
        </form>
      </div>
    </div>
  );
}

function EmptyState({ onPick }: { onPick: (t: string) => void }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-10 text-center">
      <div className="grid h-14 w-14 place-items-center rounded-2xl gradient-primary shadow-[0_0_40px_-8px_var(--primary)]">
        <Sparkles className="h-6 w-6 text-primary-foreground" />
      </div>
      <div>
        <div className="text-lg font-semibold text-foreground">Ask your Copilot anything</div>
        <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
          It knows your projects, agents, budgets, deadlines, and open risks — and speaks in ranked next actions.
        </p>
      </div>
      <div className="mx-auto grid w-full max-w-xl grid-cols-1 gap-2 sm:grid-cols-2">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => onPick(s)}
            className="rounded-lg border border-border/60 bg-panel-elevated p-3 text-left text-sm text-foreground transition hover:border-primary/40 hover:bg-panel-elevated/80"
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}

function MessageBubble({ message }: { message: UIMessage }) {
  const isUser = message.role === "user";
  const text = message.parts
    .map((p) => (p.type === "text" ? p.text : ""))
    .join("");
  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg ${
          isUser ? "bg-panel-elevated text-muted-foreground" : "gradient-primary text-primary-foreground"
        }`}
      >
        {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
      </div>
      <div
        className={`max-w-[80%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
          isUser
            ? "bg-primary/15 text-foreground"
            : "border border-border/60 bg-panel-elevated text-foreground"
        }`}
      >
        {text || <span className="text-muted-foreground">…</span>}
      </div>
    </div>
  );
}
