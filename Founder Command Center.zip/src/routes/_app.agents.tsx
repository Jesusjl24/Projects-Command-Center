import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { money } from "@/lib/analytics";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { MetricCard } from "@/components/ui/MetricCard";
import type { Agent, AgentStatus, AgentType } from "@/lib/types";
import { Bot, Cpu, DollarSign, Clock, Search, Zap } from "lucide-react";

export const Route = createFileRoute("/_app/agents")({
  head: () => ({
    meta: [
      { title: "Agents — Command Center" },
      { name: "description", content: "Global agent roster across your portfolio." },
    ],
  }),
  component: AgentsPage,
});

type Row = Agent & { projectId: string; projectName: string; spent: number };

const TYPES: (AgentType | "All")[] = ["All", "Manager", "Builder", "Security", "Research"];
const STATUSES: (AgentStatus | "All")[] = ["All", "Running", "Idle", "Paused", "Blocked"];

function AgentsPage() {
  const projects = useStore((s) => s.projects);
  const [q, setQ] = useState("");
  const [type, setType] = useState<(AgentType | "All")>("All");
  const [status, setStatus] = useState<(AgentStatus | "All")>("All");

  const rows: Row[] = useMemo(
    () =>
      projects.flatMap((p) =>
        p.agents.map((a) => ({
          ...a,
          projectId: p.id,
          projectName: p.name,
          spent: a.hourlyRate * a.hoursUsed,
        })),
      ),
    [projects],
  );

  const filtered = rows.filter((r) => {
    if (type !== "All" && r.type !== type) return false;
    if (status !== "All" && r.status !== status) return false;
    if (q && !`${r.name} ${r.role} ${r.projectName} ${r.provider} ${r.model}`.toLowerCase().includes(q.toLowerCase()))
      return false;
    return true;
  });

  const totalSpent = filtered.reduce((s, r) => s + r.spent, 0);
  const totalHours = filtered.reduce((s, r) => s + r.hoursUsed, 0);
  const running = filtered.filter((r) => r.status === "Running").length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Agents</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Every AI agent working across your portfolio, with cost, autonomy, and current task.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <MetricCard label="Agents" value={filtered.length} icon={Bot} accent="primary" />
        <MetricCard label="Running now" value={running} icon={Zap} accent="success" />
        <MetricCard label="Total hours" value={totalHours} icon={Clock} accent="info" />
        <MetricCard label="Agent spend" value={money(totalSpent)} icon={DollarSign} accent="info" />
      </div>

      <div className="panel p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search agents, roles, projects…"
              className="w-full rounded-md border border-border/70 bg-panel-elevated py-2 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/60 focus:outline-none"
            />
          </div>
          <FilterGroup label="Type" options={TYPES} value={type} onChange={(v) => setType(v as AgentType | "All")} />
          <FilterGroup label="Status" options={STATUSES} value={status} onChange={(v) => setStatus(v as AgentStatus | "All")} />
        </div>
      </div>

      <div className="panel overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-panel-elevated text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Agent</th>
                <th className="px-4 py-3 text-left font-medium">Project</th>
                <th className="px-4 py-3 text-left font-medium">Type</th>
                <th className="px-4 py-3 text-left font-medium">Model</th>
                <th className="px-4 py-3 text-left font-medium">YOLO</th>
                <th className="px-4 py-3 text-left font-medium">Status</th>
                <th className="px-4 py-3 text-right font-medium">Hours</th>
                <th className="px-4 py-3 text-right font-medium">Spend</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-sm text-muted-foreground">
                    No agents match those filters.
                  </td>
                </tr>
              ) : (
                filtered.map((r) => (
                  <tr key={`${r.projectId}-${r.id}`} className="border-t border-border/60 hover:bg-panel-elevated/60">
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground">{r.name}</div>
                      <div className="text-xs text-muted-foreground">{r.role}</div>
                    </td>
                    <td className="px-4 py-3">
                      <Link to="/projects/$id" params={{ id: r.projectId }} className="text-foreground hover:text-primary">
                        {r.projectName}
                      </Link>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1.5 rounded-md bg-panel-elevated px-2 py-0.5 text-xs text-foreground">
                        <Cpu className="h-3 w-3 text-primary" />
                        {r.type}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {r.provider} · {r.model}
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{r.yoloMode}</td>
                    <td className="px-4 py-3">
                      <StatusBadge kind="agent" value={r.status} />
                    </td>
                    <td className="px-4 py-3 text-right text-foreground">{r.hoursUsed}</td>
                    <td className="px-4 py-3 text-right font-medium text-foreground">{money(r.spent)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function FilterGroup<T extends string>({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: readonly T[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-muted-foreground">{label}:</span>
      <div className="flex flex-wrap gap-1 rounded-md border border-border/60 bg-panel-elevated p-0.5">
        {options.map((o) => (
          <button
            key={o}
            onClick={() => onChange(o)}
            className={`rounded px-2.5 py-1 text-xs transition ${
              value === o ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}
