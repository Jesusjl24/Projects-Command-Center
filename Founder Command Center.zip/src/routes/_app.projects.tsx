import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { ProjectCard } from "@/components/projects/ProjectCard";
import { cn } from "@/lib/utils";
import { Search } from "lucide-react";

const filters = ["All", "Building", "Paused", "Blocked", "Security", "High Priority"] as const;
type Filter = (typeof filters)[number];

export const Route = createFileRoute("/_app/projects")({
  head: () => ({
    meta: [
      { title: "Projects — Command Center" },
      { name: "description", content: "Filterable portfolio of AI-assisted app builds." },
      { property: "og:title", content: "Projects — Command Center" },
      { property: "og:description", content: "Filterable portfolio of AI-assisted app builds." },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  const projects = useStore((s) => s.projects);
  const [filter, setFilter] = useState<Filter>("All");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    return projects.filter((p) => {
      if (query && !`${p.name} ${p.description}`.toLowerCase().includes(query.toLowerCase())) return false;
      switch (filter) {
        case "All": return true;
        case "Building": return p.buildStatus === "Building";
        case "Paused": return p.buildStatus === "Paused";
        case "Blocked": return p.buildStatus === "Blocked";
        case "Security": return p.findings.some((f) => f.status === "Open");
        case "High Priority": return p.priority === "High" || p.priority === "Critical";
      }
    });
  }, [projects, filter, query]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Projects</h1>
        <p className="mt-1 text-sm text-muted-foreground">Your app portfolio, tracked from idea to launch.</p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                filter === f
                  ? "border-primary/40 bg-primary/15 text-primary"
                  : "border-border bg-panel text-muted-foreground hover:text-foreground",
              )}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="relative sm:w-64">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search projects…"
            className="w-full rounded-lg border border-input bg-panel py-2 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="panel p-10 text-center text-sm text-muted-foreground">No projects match this filter.</div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((p) => (
            <ProjectCard key={p.id} project={p} />
          ))}
        </div>
      )}
    </div>
  );
}
