import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { MetricCard } from "@/components/ui/MetricCard";
import type { FindingStatus, Severity } from "@/lib/types";
import { ShieldCheck, ShieldAlert, ShieldX, Ban, Check, X, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/_app/security")({
  head: () => ({
    meta: [
      { title: "Security — Command Center" },
      { name: "description", content: "Portfolio-wide launch risk review." },
    ],
  }),
  component: SecurityPage,
});

const SEV: (Severity | "All")[] = ["All", "Critical", "High", "Medium", "Low"];
const STAT: (FindingStatus | "All")[] = ["All", "Open", "Fixed", "Accepted", "False Positive"];

function SecurityPage() {
  const projects = useStore((s) => s.projects);
  const setFindingStatus = useStore((s) => s.setFindingStatus);
  const [sev, setSev] = useState<Severity | "All">("All");
  const [stat, setStat] = useState<FindingStatus | "All">("Open");

  const rows = useMemo(
    () =>
      projects.flatMap((p) =>
        p.findings.map((f) => ({ ...f, projectId: p.id, projectName: p.name })),
      ),
    [projects],
  );

  const filtered = rows.filter((r) => {
    if (sev !== "All" && r.severity !== sev) return false;
    if (stat !== "All" && r.status !== stat) return false;
    return true;
  });

  const openAll = rows.filter((r) => r.status === "Open");
  const critical = openAll.filter((r) => r.severity === "Critical").length;
  const high = openAll.filter((r) => r.severity === "High").length;
  const blockers = openAll.filter((r) => r.blocksLaunch).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Security</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Portfolio-wide launch risk board. Findings that block launch are flagged.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <MetricCard label="Open findings" value={openAll.length} icon={ShieldAlert} accent={openAll.length ? "warning" : "success"} />
        <MetricCard label="Critical" value={critical} icon={ShieldX} accent={critical ? "danger" : "success"} />
        <MetricCard label="High" value={high} icon={AlertTriangle} accent={high ? "warning" : "success"} />
        <MetricCard label="Blocking launch" value={blockers} icon={Ban} accent={blockers ? "danger" : "success"} />
      </div>

      <div className="panel p-4">
        <div className="flex flex-wrap items-center gap-3">
          <FilterGroup label="Severity" options={SEV} value={sev} onChange={(v) => setSev(v as Severity | "All")} />
          <FilterGroup label="Status" options={STAT} value={stat} onChange={(v) => setStat(v as FindingStatus | "All")} />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="panel flex flex-col items-center justify-center gap-3 p-12 text-center">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-success/15 text-success">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div className="text-sm text-muted-foreground">No findings match those filters.</div>
        </div>
      ) : (
        <ul className="space-y-3">
          {filtered.map((f) => (
            <li key={`${f.projectId}-${f.id}`} className="panel p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <StatusBadge kind="severity" value={f.severity} />
                    <StatusBadge kind="finding" value={f.status} />
                    {f.blocksLaunch && (
                      <span className="inline-flex items-center gap-1 rounded-full border border-destructive/30 bg-destructive/15 px-2 py-0.5 text-[11px] font-medium text-destructive">
                        <Ban className="h-3 w-3" /> Blocks launch
                      </span>
                    )}
                    <span className="text-xs text-muted-foreground">{f.category}</span>
                  </div>
                  <h3 className="mt-2 text-sm font-semibold text-foreground">{f.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{f.recommendation}</p>
                  <div className="mt-2 text-xs text-muted-foreground">
                    Project:{" "}
                    <Link to="/projects/$id" params={{ id: f.projectId }} className="text-foreground hover:text-primary">
                      {f.projectName}
                    </Link>
                    {f.owner ? <span> · Owner: {f.owner}</span> : null}
                  </div>
                </div>
                {f.status === "Open" && (
                  <div className="flex shrink-0 items-center gap-2">
                    <button
                      onClick={() => setFindingStatus(f.projectId, f.id, "Fixed")}
                      className="inline-flex items-center gap-1 rounded-md border border-success/30 bg-success/10 px-2.5 py-1.5 text-xs text-success hover:bg-success/20"
                    >
                      <Check className="h-3.5 w-3.5" /> Mark fixed
                    </button>
                    <button
                      onClick={() => setFindingStatus(f.projectId, f.id, "Accepted")}
                      className="inline-flex items-center gap-1 rounded-md border border-border/60 bg-panel-elevated px-2.5 py-1.5 text-xs text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-3.5 w-3.5" /> Accept risk
                    </button>
                  </div>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function FilterGroup<T extends string>({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: readonly T[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-muted-foreground">{label}:</span>
      <div className="flex flex-wrap gap-1 rounded-md border border-border/60 bg-panel-elevated p-0.5">
        {options.map((o) => (
          <button
            key={o}
            onClick={() => onChange(o)}
            className={`rounded px-2.5 py-1 text-xs transition ${
              value === o ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}
