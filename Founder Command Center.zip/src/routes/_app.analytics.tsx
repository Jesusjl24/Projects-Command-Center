import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { useStore } from "@/lib/store";
import { analytics, launchReadiness, healthScore, money, daysRemaining } from "@/lib/analytics";
import { MetricCard } from "@/components/ui/MetricCard";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { BarChart3, DollarSign, Server, Clock, TrendingUp } from "lucide-react";

export const Route = createFileRoute("/_app/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics — Command Center" },
      { name: "description", content: "Portfolio analytics and cost breakdowns." },
    ],
  }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const projects = useStore((s) => s.projects);

  const rows = useMemo(
    () =>
      projects
        .map((p) => {
          const a = analytics(p);
          return {
            p,
            spent: a.spent,
            agentSpent: a.agentSpent,
            stackSpent: a.stackSpent,
            budget: p.budget,
            pressure: a.budgetPressure,
            readiness: launchReadiness(p),
            health: healthScore(p),
            days: daysRemaining(p.deadline),
          };
        })
        .sort((a, b) => b.spent - a.spent),
    [projects],
  );

  const totalSpent = rows.reduce((s, r) => s + r.spent, 0);
  const totalBudget = rows.reduce((s, r) => s + r.budget, 0);
  const monthlyStack = projects.reduce((s, p) => s + p.stackMonthlyCost, 0);
  const totalHours = projects.reduce((s, p) => s + p.agents.reduce((x, a) => x + a.hoursUsed, 0), 0);
  const maxBarSpend = Math.max(1, ...rows.map((r) => r.budget));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Analytics</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Where your build budget goes, how each project is trending, and what's due next.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <MetricCard label="Total spent" value={money(totalSpent)} icon={DollarSign} accent="primary" />
        <MetricCard label="Total budget" value={money(totalBudget)} icon={TrendingUp} accent="info" />
        <MetricCard label="Monthly stack" value={money(monthlyStack)} icon={Server} accent="info" />
        <MetricCard label="Agent hours" value={totalHours} icon={Clock} accent="success" />
      </div>

      <div className="panel p-5">
        <div className="mb-4 flex items-center gap-2">
          <BarChart3 className="h-4 w-4 text-primary" />
          <h2 className="text-sm font-semibold text-foreground">Cost by project</h2>
        </div>
        <div className="space-y-4">
          {rows.map((r) => {
            const agentPct = (r.agentSpent / maxBarSpend) * 100;
            const stackPct = (r.stackSpent / maxBarSpend) * 100;
            const budgetPct = (r.budget / maxBarSpend) * 100;
            return (
              <div key={r.p.id}>
                <div className="mb-1.5 flex flex-wrap items-baseline justify-between gap-2">
                  <Link to="/projects/$id" params={{ id: r.p.id }} className="text-sm font-medium text-foreground hover:text-primary">
                    {r.p.name}
                  </Link>
                  <div className="text-xs text-muted-foreground">
                    <span className="text-foreground">{money(r.spent)}</span> spent of {money(r.budget)} ·{" "}
                    <span className={r.pressure > 80 ? "text-warning" : "text-muted-foreground"}>{r.pressure}%</span>
                  </div>
                </div>
                <div className="relative h-6 w-full overflow-hidden rounded-md bg-panel-elevated">
                  <div className="absolute inset-y-0 left-0 border-r border-border/60" style={{ width: `${budgetPct}%` }} />
                  <div className="absolute inset-y-0 left-0 bg-primary/70" style={{ width: `${agentPct}%` }} />
                  <div className="absolute inset-y-0 bg-info/60" style={{ left: `${agentPct}%`, width: `${stackPct}%` }} />
                </div>
                <div className="mt-1 flex flex-wrap gap-3 text-[11px] text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-primary/70" /> Agent {money(r.agentSpent)}</span>
                  <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-info/60" /> Stack {money(r.stackSpent)}</span>
                  <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-sm border border-border" /> Budget</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="panel p-5">
          <h2 className="mb-4 text-sm font-semibold text-foreground">Project health</h2>
          <div className="space-y-3">
            {rows.map((r) => (
              <div key={r.p.id}>
                <div className="flex items-baseline justify-between text-xs">
                  <Link to="/projects/$id" params={{ id: r.p.id }} className="text-foreground hover:text-primary">
                    {r.p.name}
                  </Link>
                  <span className="text-muted-foreground">
                    <span className="text-foreground">{r.health}%</span> health · {r.readiness}% ready
                  </span>
                </div>
                <ProgressBar
                  value={r.health}
                  tone={r.health > 70 ? "success" : r.health > 40 ? "primary" : "warning"}
                  className="mt-1"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="panel p-5">
          <h2 className="mb-4 text-sm font-semibold text-foreground">Deadline pressure</h2>
          <div className="overflow-hidden rounded-lg border border-border/60">
            <table className="w-full text-sm">
              <thead className="bg-panel-elevated text-[11px] uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 text-left font-medium">Project</th>
                  <th className="px-3 py-2 text-left font-medium">Deadline</th>
                  <th className="px-3 py-2 text-right font-medium">Days</th>
                  <th className="px-3 py-2 text-right font-medium">Ready</th>
                </tr>
              </thead>
              <tbody>
                {[...rows]
                  .sort((a, b) => a.days - b.days)
                  .map((r) => (
                    <tr key={r.p.id} className="border-t border-border/60 hover:bg-panel-elevated/60">
                      <td className="px-3 py-2">
                        <Link to="/projects/$id" params={{ id: r.p.id }} className="text-foreground hover:text-primary">
                          {r.p.name}
                        </Link>
                      </td>
                      <td className="px-3 py-2 text-muted-foreground">{r.p.deadline}</td>
                      <td className={`px-3 py-2 text-right ${r.days < 7 ? "text-warning" : r.days < 0 ? "text-destructive" : "text-foreground"}`}>
                        {r.days}
                      </td>
                      <td className="px-3 py-2 text-right text-foreground">{r.readiness}%</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
