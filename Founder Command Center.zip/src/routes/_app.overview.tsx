import { createFileRoute, Link } from "@tanstack/react-router";
import { useStore } from "@/lib/store";
import { portfolioAnalytics, money, launchReadiness, daysRemaining } from "@/lib/analytics";
import { MetricCard } from "@/components/ui/MetricCard";
import { ActivityStream } from "@/components/ui/ActivityStream";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Rocket, DollarSign, Server, Clock, ShieldAlert, Hammer, ArrowRight, Sparkles } from "lucide-react";

export const Route = createFileRoute("/_app/overview")({
  head: () => ({
    meta: [
      { title: "Overview — Command Center" },
      { name: "description", content: "Portfolio launch readiness, agent activity, deadlines, and next action." },
      { property: "og:title", content: "Overview — Command Center" },
      { property: "og:description", content: "Portfolio launch readiness, agent activity, deadlines, and next action." },
    ],
  }),
  component: OverviewPage,
});

function OverviewPage() {
  const projects = useStore((s) => s.projects);
  const loaded = useStore((s) => s.loaded);
  const seedDemo = useStore((s) => s.seedDemo);
  const stats = portfolioAnalytics(projects);

  if (loaded && projects.length === 0) {
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <div className="panel max-w-md p-8 text-center">
          <Sparkles className="mx-auto h-8 w-8 text-primary" />
          <h2 className="mt-4 text-lg font-semibold">Your portfolio is empty</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Load the demo portfolio to explore the command center, or create your first project.
          </p>
          <button
            onClick={() => void seedDemo()}
            className="mt-5 inline-flex items-center gap-1.5 rounded-md gradient-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            Load demo portfolio
          </button>
        </div>
      </div>
    );
  }

  const allActivity = projects
    .flatMap((p) => p.activity.map((a) => ({ ...a, projectId: p.id, projectName: p.name })))
    .sort((a, b) => (a.timestamp < b.timestamp ? 1 : -1))
    .slice(0, 8);

  const upcoming = [...projects].sort((a, b) => (a.deadline < b.deadline ? -1 : 1)).slice(0, 5);

  const atRisk = projects
    .map((p) => ({ p, r: launchReadiness(p) }))
    .filter((x) => x.r < 60 || x.p.findings.some((f) => f.status === "Open" && (f.severity === "High" || f.severity === "Critical")))
    .sort((a, b) => a.r - b.r);

  const nextAction =
    atRisk[0]?.p.findings.find((f) => f.status === "Open" && (f.severity === "High" || f.severity === "Critical"))?.recommendation ||
    "Confirm MVP acceptance criteria for the Command Center project.";

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Portfolio overview</h1>
          <p className="mt-1 text-sm text-muted-foreground">Command cockpit for your AI-assisted app builds.</p>
        </div>
        <Link
          to="/projects"
          className="inline-flex items-center gap-1.5 rounded-md gradient-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          View projects <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <MetricCard label="Launch readiness" value={`${stats.avgReadiness}%`} icon={Rocket} accent="primary" hint="portfolio avg" />
        <MetricCard label="Est. build total" value={money(stats.totalBudget)} icon={DollarSign} accent="info" />
        <MetricCard label="Monthly stack" value={money(stats.monthlyStack)} icon={Server} accent="info" />
        <MetricCard label="Agent hours" value={stats.agentHours} icon={Clock} accent="primary" />
        <MetricCard label="Open risks" value={stats.openFindings} icon={ShieldAlert} accent={stats.openFindings ? "danger" : "success"} />
        <MetricCard label="Active builds" value={stats.activeBuilds} icon={Hammer} accent="success" />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="panel p-5 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-foreground">AI activity stream</h2>
            <span className="text-[11px] text-muted-foreground">last 8 events</span>
          </div>
          <ActivityStream events={allActivity} />
        </div>

        <div className="space-y-6">
          <div className="panel p-5">
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <h2 className="text-sm font-semibold text-foreground">Next recommended action</h2>
            </div>
            <p className="text-sm text-muted-foreground">{nextAction}</p>
          </div>

          <div className="panel p-5">
            <h2 className="mb-3 text-sm font-semibold text-foreground">Portfolio health</h2>
            <div className="space-y-1">
              <div className="flex items-baseline justify-between">
                <span className="text-xs text-muted-foreground">Avg health</span>
                <span className="text-sm font-medium text-foreground">{stats.avgHealth}%</span>
              </div>
              <ProgressBar value={stats.avgHealth} tone={stats.avgHealth > 70 ? "success" : stats.avgHealth > 40 ? "primary" : "warning"} />
              <div className="mt-3 flex items-baseline justify-between">
                <span className="text-xs text-muted-foreground">Avg launch readiness</span>
                <span className="text-sm font-medium text-foreground">{stats.avgReadiness}%</span>
              </div>
              <ProgressBar value={stats.avgReadiness} />
              <div className="mt-3 flex items-baseline justify-between">
                <span className="text-xs text-muted-foreground">Spent to date</span>
                <span className="text-sm font-medium text-foreground">{money(stats.totalSpent)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="panel p-5">
          <h2 className="mb-4 text-sm font-semibold text-foreground">Upcoming deadlines</h2>
          <div className="overflow-hidden rounded-lg border border-border/60">
            <table className="w-full text-sm">
              <thead className="bg-panel-elevated text-[11px] uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 text-left font-medium">Project</th>
                  <th className="px-3 py-2 text-left font-medium">Deadline</th>
                  <th className="px-3 py-2 text-right font-medium">Days</th>
                </tr>
              </thead>
              <tbody>
                {upcoming.map((p) => {
                  const dr = daysRemaining(p.deadline);
                  return (
                    <tr key={p.id} className="border-t border-border/60 hover:bg-panel-elevated/60">
                      <td className="px-3 py-2">
                        <Link to="/projects/$id" params={{ id: p.id }} className="font-medium text-foreground hover:text-primary">
                          {p.name}
                        </Link>
                      </td>
                      <td className="px-3 py-2 text-muted-foreground">{p.deadline}</td>
                      <td className={`px-3 py-2 text-right ${dr < 7 ? "text-warning" : "text-foreground"}`}>{dr}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="panel p-5">
          <h2 className="mb-4 text-sm font-semibold text-foreground">At-risk projects</h2>
          {atRisk.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 py-8 text-center">
              <div className="grid h-10 w-10 place-items-center rounded-full bg-success/15 text-success">
                <ShieldAlert className="h-5 w-5" />
              </div>
              <p className="text-sm text-muted-foreground">All projects healthy — nothing to escalate.</p>
            </div>
          ) : (
            <ul className="space-y-3">
              {atRisk.slice(0, 5).map(({ p, r }) => (
                <li key={p.id} className="rounded-lg border border-border/60 p-3 hover:border-primary/40">
                  <Link to="/projects/$id" params={{ id: p.id }} className="block">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-medium text-foreground">{p.name}</span>
                      <StatusBadge kind="priority" value={p.priority} />
                    </div>
                    <div className="mt-2 flex items-baseline justify-between text-xs text-muted-foreground">
                      <span>Launch readiness</span>
                      <span className="font-medium text-foreground">{r}%</span>
                    </div>
                    <ProgressBar value={r} tone={r < 40 ? "danger" : "warning"} className="mt-1" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
