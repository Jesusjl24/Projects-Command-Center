import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

type ChatRequestBody = { messages?: unknown; context?: string };

const SYSTEM_PROMPT = `You are the AI Copilot inside a solo founder's Project Command Center.

Your job: help the founder plan, unblock, and ship AI-assisted app builds. Be direct, senior, and specific. Prefer bullet lists and concrete next actions over prose. Reference the founder's projects, agents, deadlines, budgets, and security findings when they're provided in the CONTEXT block below.

Guidelines:
- If asked "what should I do next", give 3 ranked next actions tied to specific projects.
- If asked to draft PDR sections, produce tight, product-manager-quality copy.
- Flag risks (deadline slip, budget pressure, open Critical/High security findings) proactively.
- Never invent projects, agents, or numbers that aren't in the CONTEXT.
- Keep responses under ~250 words unless the user asks for more depth.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { messages, context } = (await request.json()) as ChatRequestBody;
        if (!Array.isArray(messages)) {
          return new Response("Messages are required", { status: 400 });
        }

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);
        const model = gateway("google/gemini-3-flash-preview");

        const system = context
          ? `${SYSTEM_PROMPT}\n\n=== CONTEXT ===\n${context}\n=== END CONTEXT ===`
          : SYSTEM_PROMPT;

        const result = streamText({
          model,
          system,
          messages: await convertToModelMessages(messages as UIMessage[]),
        });

        return result.toUIMessageStreamResponse({
          originalMessages: messages as UIMessage[],
        });
      },
    },
  },
});
