CREATE TABLE public.agent_runs (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null,
  owner_id uuid not null,
  agent_type text not null,
  agent_name text not null,
  summary text not null,
  changes jsonb not null default '{}'::jsonb,
  model text,
  status text not null default 'success',
  created_at timestamptz not null default now()
);

CREATE INDEX agent_runs_project_id_created_at_idx ON public.agent_runs (project_id, created_at DESC);
CREATE INDEX agent_runs_owner_id_idx ON public.agent_runs (owner_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.agent_runs TO authenticated;
GRANT ALL ON public.agent_runs TO service_role;

ALTER TABLE public.agent_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own agent runs"
  ON public.agent_runs FOR SELECT
  USING (auth.uid() = owner_id);

CREATE POLICY "Users can insert their own agent runs"
  ON public.agent_runs FOR INSERT
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can delete their own agent runs"
  ON public.agent_runs FOR DELETE
  USING (auth.uid() = owner_id);