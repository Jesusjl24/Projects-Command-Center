
# Project Command Center — Phase 1–4 Build Plan

Scope: deliver a polished, clickable, responsive dark-mode SaaS dashboard with demo data. Phases 5–12 (global Agents/Security/Analytics/Settings pages, Supabase persistence, AI features, orchestration) are deferred to follow-up plans so we don't overbuild before the core flow is validated.

## What ships in this plan

1. **App shell** — dark theme, fixed sidebar (desktop) / drawer (mobile), top bar, 6 nav routes.
2. **Demo data layer** — typed mock projects, agents, tasks, findings, activity.
3. **Overview page** — metric cockpit, AI activity stream, deadlines, at-risk projects, next action.
4. **Projects page** — filterable premium project cards.
5. **Project Detail page** — hero, snapshot, 8 tabs (Overview / Mission / Stack / Agents / Build / Security / Activity / Handoff), copy-to-clipboard handoff markdown.
6. **Placeholder pages** — Agents, Security, Analytics, Settings render "Coming in next phase" stubs so no sidebar link is dead.

## Design direction

Dark navy/black background, soft elevated panels, rounded-xl cards, purple + blue gradient accents, green success, amber caution, rose/red risk. CRM-style compact tables. Existing Tailwind v4 tokens in `src/styles.css` will be extended (not replaced) with a dark-first palette and semantic status colors. No hardcoded color classes in components.

## Route structure (TanStack Start file-based)

```
src/routes/
  __root.tsx              (updated: real title/meta, keeps <Outlet/>)
  index.tsx               (redirect → /overview; replaces placeholder)
  _app.tsx                (layout: sidebar + topbar shell, <Outlet/>)
  _app.overview.tsx       Phase 2
  _app.projects.tsx       Phase 3
  _app.projects.$id.tsx   Phase 4
  _app.agents.tsx         stub
  _app.security.tsx       stub
  _app.analytics.tsx      stub
  _app.settings.tsx       stub
```

Each route file sets its own `head()` with route-specific title + description.

## Data model & helpers

`src/lib/types.ts` — Project, Agent, Task, Milestone, SecurityFinding, Decision, TechStack, ActivityEvent types matching the spec fields.

`src/lib/demo-data.ts` — 6 seeded projects (Command Center, Personal CRM, Barbershop Booking, AI Roadmap, PS Pathways, Financial Research) with full nested agents/tasks/findings/decisions/activity per spec.

`src/lib/analytics.ts` — pure helpers:
- `daysBetween`, `money`, `daysRemaining`
- `healthScore(project)` — weighted: progress 40%, velocity 20%, security penalty 25%, blocked-task penalty 15%
- `launchReadiness(project)` — progress 40%, no high/critical findings 30%, handoff/decisions 15%, open tasks 15%
- `analytics(project)` — spent, remaining, budget pressure, elapsed/remaining days, cost breakdown
- `portfolioAnalytics(projects)` — sums + averages for Overview metrics
- `generateHandoff(project)` — markdown per Phase 4 spec

`src/lib/store.ts` — Zustand store wrapping demo data, exposing `projects`, `updateProject`, `toggleFindingStatus`, etc. Structured so a Supabase adapter can slot in later (Phase 9).

## Component structure

```
src/components/
  layout/AppSidebar.tsx      (shadcn sidebar, collapsible=icon, mobile sheet)
  layout/TopBar.tsx
  ui/MetricCard.tsx
  ui/StatusBadge.tsx         (stage / buildStatus / priority / severity variants)
  ui/ProgressBar.tsx
  ui/CostBreakdown.tsx
  ui/Timeline.tsx
  ui/ActivityStream.tsx
  projects/ProjectCard.tsx
  projects/ProjectFilters.tsx
  projects/ProjectHero.tsx
  projects/BuildSnapshot.tsx
  projects/tabs/{Overview,Mission,Stack,Agents,Build,Security,Activity,Handoff}Tab.tsx
  tables/AgentsTable.tsx
  tables/SecurityFindingsTable.tsx
  tables/TasksTable.tsx
```

Uses existing shadcn primitives (card, table, tabs, badge, button, progress, sheet, sidebar, tooltip, sonner for toast).

## Overview page contents

Metric cards row: Portfolio launch readiness, Total est. build cost, Monthly stack cost, Total agent hours, Open security risks, Active builds. Below: two-column grid — left: AI activity stream + upcoming deadlines table; right: portfolio health summary, at-risk projects list, next recommended action card.

## Projects page

Filter chips (All / Building / Paused / Blocked / Security / High Priority) + search. Responsive grid (1 col mobile, 2 tablet, 3 desktop) of ProjectCards. Card click → `/projects/$id`.

## Project Detail page

Sticky hero with back link, name, badges, progress, action buttons (Pause/Resume toggles buildStatus in store; Copy Handoff writes markdown via `navigator.clipboard` + toast; Run Security Review + Edit are toast placeholders). BuildSnapshot card row. Tabs component with all 8 tabs implemented per spec. Handoff tab renders `<pre>` preview of `generateHandoff(project)` with Copy button.

## Responsiveness & polish

- Sidebar: `collapsible="icon"` desktop, `Sheet` drawer on mobile via existing shadcn sidebar.
- Tables collapse to stacked cards under `sm`.
- Tabs use horizontal scroll on mobile.
- Touch targets ≥ 44px, focus rings on all interactive elements.
- Semantic h1/h2 hierarchy, alt text, aria-labels.

## Technical notes

- Tailwind v4 tokens in `src/styles.css`: extend `:root` (light kept for future) and expand `.dark` palette; add `--color-success`, `--color-warning`, `--color-danger`, `--gradient-primary`, `--shadow-panel`. Force dark mode by adding `class="dark"` to `<html>` in `__root.tsx` shell.
- State: Zustand (add via `bun add zustand`). Router already has TanStack Query available for future Supabase reads.
- No new server functions, no Supabase calls in this phase.
- `src/routes/index.tsx` becomes a `redirect({ to: '/overview' })` in `beforeLoad` — removes the placeholder image.

## Verification before finishing

- `bun run build` passes (harness runs typecheck).
- Manual click-through of all 6 sidebar routes at desktop + mobile viewport via Playwright screenshot.
- Copy Handoff produces valid markdown for at least one project.

## Explicitly deferred (future plans)

Phases 5–12: global Agents/Security/Analytics/Settings full implementations, Supabase schema + RLS + auth, AI-assisted generators, orchestration simulation, YOLO guardrails. Placeholder routes exist so nothing is broken.
